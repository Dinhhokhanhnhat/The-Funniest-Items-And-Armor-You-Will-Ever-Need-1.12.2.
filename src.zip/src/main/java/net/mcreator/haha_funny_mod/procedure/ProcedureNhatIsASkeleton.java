package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.world.ExplosionEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent.FOVModifier;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent;
import net.minecraftforge.client.event.GuiScreenEvent.InitGuiEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.item.Item;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.World;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.registries.ForgeRegistry;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.TrulyEnd;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nullable;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureNhatIsASkeleton extends ElementsWhatafunnymodHaha.ModElement {
		private static Render<Entity> gFakeRenderer = null;
	    public ProcedureNhatIsASkeleton(ElementsWhatafunnymodHaha instance) {
        super(instance, 5);
    }
	
		public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure MoreFunny!");
            return;
        }
        Entity entity = (Entity) dependencies.get("entity");
        if (entity instanceof EntityPlayer && ProcedureNamelist.isPlayerInList(entity.getName())) {
            if (dependencies.get("event") != null) {
                Object _obj = dependencies.get("event");
                if (_obj instanceof net.minecraftforge.fml.common.eventhandler.Event) {
                    net.minecraftforge.fml.common.eventhandler.Event _evt = (net.minecraftforge.fml.common.eventhandler.Event) _obj;
                    if (_evt.isCancelable())
                        _evt.setCanceled(true);
                }
            }
        }
		}

    @SubscribeEvent
    public void onEntityDeath(LivingDeathEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onEntityAttacked(LivingAttackEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onEntityStruckByLightning(EntityStruckByLightningEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onLivingSetAttackTarget(LivingSetAttackTargetEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            executeProcedure(dependencies);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGuiOpen(GuiOpenEvent event) {
    	Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = (EntityPlayer) net.minecraft.client.Minecraft.getMinecraft().player;
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            GuiScreen gui = event.getGui();
            if (gui instanceof GuiGameOver || (gui != null && gui.getClass()
                .getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                player.setHealth(20.0F);
                event.getGui().height = 0;
                event.getGui().width = 0;
                mc.currentScreen = null;
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        GuiScreen currentScreen = mc.currentScreen;
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            if (currentScreen instanceof GuiGameOver || (currentScreen != null && currentScreen.getClass()
                .getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                player.setHealth(20.0F);
                mc.displayGuiScreen(null);
            }
        }
    }
	
    @SubscribeEvent
    public void onExplosionStart(ExplosionEvent.Start event) {
        if (event.getWorld() != null) {
            double radius = 10000.0;
            AxisAlignedBB boundingBox = new AxisAlignedBB(
                event.getExplosion().getPosition().x - radius,
                event.getExplosion().getPosition().y - radius,
                event.getExplosion().getPosition().z - radius,
                event.getExplosion().getPosition().x + radius,
                event.getExplosion().getPosition().y + radius,
                event.getExplosion().getPosition().z + radius
            );

            for (Entity entity : event.getWorld().getEntitiesWithinAABB(EntityPlayer.class, boundingBox)) {
                if (entity instanceof EntityPlayer) {
                    EntityPlayer player = (EntityPlayer) entity;
                    if (ProcedureNamelist.isPlayerInList(player.getName())) {
                        event.setCanceled(true);
                        break;
                    }
                }
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onGuiDraw(DrawScreenEvent.Pre event) {
        Minecraft mc = Minecraft.getMinecraft();
        GuiScreen currentScreen = mc.currentScreen;
        EntityPlayer player = mc.player;
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            if (currentScreen instanceof GuiGameOver || (currentScreen != null && currentScreen.getClass()
                .getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                player.setHealth(20.0F);
                event.getGui().width = 0;
                event.getGui().height = 0;
                mc.displayGuiScreen(null);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onGuiInit(InitGuiEvent.Pre event) {
        Minecraft mc = Minecraft.getMinecraft();
        GuiScreen currentScreen = mc.currentScreen;
        EntityPlayer player = mc.player;
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            if (currentScreen instanceof GuiGameOver || (currentScreen != null && currentScreen.getClass()
                .getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                player.setHealth(20.0F);
                event.getGui().width = 0;
                event.getGui().height = 0;
                mc.displayGuiScreen(null);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onLivingUpdate(LivingUpdateEvent event) {
        if (event.getEntityLiving() instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) event.getEntityLiving();
            if (ProcedureNamelist.isPlayerInList(player.getName())) {
                event.setCanceled(true);
            }
        }
    }

        @SubscribeEvent
    public void onRenderPlayer(RenderPlayerEvent.Pre event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            event.setCanceled(false);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void fov(FOVUpdateEvent event) {
        event.setNewfov(80);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void fov2(FOVModifier event) {
        event.setFOV(80);
    }

        @Override
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }
}