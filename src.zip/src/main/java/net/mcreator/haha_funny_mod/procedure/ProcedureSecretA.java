package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.common.MinecraftForge;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureSecretA extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureSecretA(ElementsWhatafunnymodHaha instance) {
		super(instance, 58);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	MinecraftForge.EVENT_BUS.shutdown();
	}
}
