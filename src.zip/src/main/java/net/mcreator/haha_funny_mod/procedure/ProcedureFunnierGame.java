package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.ICommandSender;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemHahaArmor;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.potion.PotionFunniesPotion;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureFunnierGame extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureFunnierGame(ElementsWhatafunnymodHaha instance) {
		super(instance, 47);
	}
	
@SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
    	Minecraft mc = Minecraft.getMinecraft();
        GuiScreen guiScreenIn = event.getGui();
        if (guiScreenIn != null && (guiScreenIn instanceof net.minecraft.client.gui.GuiGameOver ||
                guiScreenIn.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
            mc.currentScreen = null;
            event.setCanceled(true);
        }
    }
    
	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure FunnierGame!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) entity;
			player.capabilities.allowEdit = true;
			player.sendPlayerAbilities();
			player.capabilities.allowFlying = true;
			player.sendPlayerAbilities();
			player.capabilities.disableDamage = true;
			player.sendPlayerAbilities();
			player.updateBlocked = false;
			player.deathTime = -2147483648;
			player.hurtTime = -2147483648;
			player.setHealth(20.0F);
			player.isDead = false;
			if (!player.world.loadedEntityList.contains(player)) {
				player.world.loadedEntityList.add(player);
			}
			if (!player.inventory.hasItemStack(new ItemStack(ItemHahaArmor.helmet))) {
				player.inventory.armorInventory.set(3, new ItemStack(ItemHahaArmor.helmet, 1));
				if (player instanceof EntityPlayerMP) {
					((EntityPlayerMP) player).inventory.markDirty();
				}
			}
			if (!player.inventory.hasItemStack(new ItemStack(ItemHahaArmor.body))) {
				player.inventory.armorInventory.set(2, new ItemStack(ItemHahaArmor.body, 1));
				if (player instanceof EntityPlayerMP) {
					((EntityPlayerMP) player).inventory.markDirty();
				}
			}
			if (!player.inventory.hasItemStack(new ItemStack(ItemHahaArmor.legs))) {
				player.inventory.armorInventory.set(1, new ItemStack(ItemHahaArmor.legs, 1));
				if (player instanceof EntityPlayerMP) {
					((EntityPlayerMP) player).inventory.markDirty();
				}
			}
			if (!player.inventory.hasItemStack(new ItemStack(ItemHahaArmor.boots))) {
				player.inventory.armorInventory.set(0, new ItemStack(ItemHahaArmor.boots, 1));
				if (player instanceof EntityPlayerMP) {
					((EntityPlayerMP) player).inventory.markDirty();
				}
			}
			if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block))) {
				ItemStack _setstack = new ItemStack(ItemHahaFunnySword.block, 1);
				ItemHandlerHelper.giveItemToPlayer(player, _setstack);
			}
			Minecraft mc = Minecraft.getMinecraft();
				    if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
                	mc.currentScreen = null;
        }
		}
	}
}
