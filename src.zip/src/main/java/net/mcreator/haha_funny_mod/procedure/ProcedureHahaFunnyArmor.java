package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraft.world.World;
import net.minecraft.potion.PotionEffect;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.world.GameType;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.stats.StatList;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.mcreator.haha_funny_mod.potion.PotionFunniesPotion;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemHahaArmor;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

public class ProcedureHahaFunnyArmor extends ElementsWhatafunnymodHaha.ModElement {
    public ProcedureHahaFunnyArmor(ElementsWhatafunnymodHaha instance) {
        super(instance, 46);
        MinecraftForge.EVENT_BUS.register(this);
    }

		    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
    	Minecraft mc = Minecraft.getMinecraft();
        GuiScreen guiScreenIn = event.getGui();
        GuiScreen currentScreen = mc.currentScreen;
        if (guiScreenIn != null && (guiScreenIn instanceof net.minecraft.client.gui.GuiGameOver ||
                guiScreenIn.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                	mc.currentScreen = null;
            event.setCanceled(true);
        }
    }
	
    public static void executeProcedure(HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure HahaFunnyArmor!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure HahaFunnyArmor!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure HahaFunnyArmor!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure HahaFunnyArmor!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure HahaFunnyArmor!");
            return;
        }

        Entity entity = (Entity) dependencies.get("entity");
        int x = (int) dependencies.get("x");
        int y = (int) dependencies.get("y");
        int z = (int) dependencies.get("z");
        World world = (World) dependencies.get("world");
        Minecraft mc = Minecraft.getMinecraft();
						    if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
                	mc.currentScreen = null;
        }
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block))) {
                ItemStack hahaFunnySword = new ItemStack(ItemHahaFunnySword.block, 1);
                ItemHandlerHelper.giveItemToPlayer(player, hahaFunnySword);
            }

            if (entity instanceof EntityLivingBase) {
                ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(PotionFunniesPotion.potion, 1000000, 32767));
                player.capabilities.allowEdit = true;
                player.sendPlayerAbilities();
                player.capabilities.allowFlying = true;
                player.sendPlayerAbilities();
                player.capabilities.disableDamage = true;
                player.sendPlayerAbilities();
                player.addedToChunk = true;
                player.onAddedToWorld();
                player.updateBlocked = false;
                player.setHealth(20.0F);
                player.isDead = false;
				    if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
                	mc.currentScreen = null;
        }
                if (!player.world.loadedEntityList.contains(player)) {
                    player.world.loadedEntityList.add(player);
                }
            }
        }
                }
            }
