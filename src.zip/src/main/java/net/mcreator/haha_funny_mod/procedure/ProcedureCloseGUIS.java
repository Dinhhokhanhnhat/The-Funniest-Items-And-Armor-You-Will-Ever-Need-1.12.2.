package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureCloseGUIS extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureCloseGUIS(ElementsWhatafunnymodHaha instance) {
		super(instance, 17);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure CloseGUIS!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
	}
}
