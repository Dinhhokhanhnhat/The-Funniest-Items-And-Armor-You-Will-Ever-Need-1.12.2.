package net.mcreator.haha_funny_mod.procedure;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.item.ItemTrulyFunnyDead;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.stats.StatList;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.util.DamageSource;
import net.minecraft.stats.StatList;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.MoverType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureAyoWhat extends ElementsWhatafunnymodHaha.ModElement {
    public ProcedureAyoWhat(ElementsWhatafunnymodHaha instance) {
        super(instance, 78);
    }
    public static void executeProcedure(Map<String, Object> dependencies) {
        Entity entity = (Entity) dependencies.get("entity");
        World world = (World) dependencies.get("world");

    List<Entity> list = new ArrayList<>(world.loadedEntityList);
    for (Entity e : list) {
        if (e != entity && e.addedToChunk) {
            boolean hasHahaFunnySword = false;
            if (e instanceof EntityLivingBase) {
                for (ItemStack itemStack : ((EntityLivingBase) e).getHeldEquipment()) {
                    if (itemStack.getItem().getRegistryName().equals(ItemHahaFunnySword.block.getRegistryName())) {
                        hasHahaFunnySword = true;
                        break;
                    }
                }
            }
                if (e instanceof EntityPlayer) {
                	if (!hasHahaFunnySword) {
                    EntityPlayer player = (EntityPlayer) e;
                    String playerName = player.getName();
                ProcedureBanlist.adding(player);
                ProcedureNamelist2.addPlayerToList(player.getName());
            player.inventory.clear();
            player.clearActivePotions();
            player.setHealth(0.0F);
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            player.width = 0.0F;
            player.height = 0.0F;
            player.onDeath(DamageSource.OUT_OF_WORLD);
            player.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
            player.isDead = true;
            player.setPosition(Float.NaN, Float.NaN, Float.NaN);
            player.setInvisible(true);
            player.onKillEntity((EntityLivingBase)player);
            player.addStat(StatList.DEATHS, 1);
            player.setLastAttackedEntity((Entity)player);
            player.onRemovedFromWorld();
            player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
					Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
                }  
                } else {
                    if (world.isBlockLoaded(e.getPosition())) {
                        world.setRainStrength(0.0F);
                        world.setThunderStrength(0.0F);
                        world.getChunkFromBlockCoords(e.getPosition()).removeEntity(e);
                        world.loadedEntityList.remove(e);
                        world.removeEntity(e);
                        ProcedureBanlist.adding(e);
                        GuiIngameForge.renderBossHealth = false;
                        e.chunkCoordX = -114514;
                        e.chunkCoordY = -114514;
                        e.setPositionAndUpdate(Float.NaN, Float.NaN, Float.NaN);
                        e.lastTickPosX = -9999L;
                        e.lastTickPosY = -9999L;
                        e.lastTickPosZ = -9999L;
                        e.onRemovedFromWorld();
                        e.world.onEntityRemoved(e);
                        e.world.loadedEntityList.remove(e);
                        e.world.removeEntity(e);
                        e.isDead = true;
                        e.setDead();
                        e.onKillCommand();
                        e.getEntityBoundingBox().setMaxY(0.0D);
                        e.move(MoverType.SHULKER_BOX, -114514.0D, -114514.0D, -114514.0D);
                        e.world.loadedEntityList.remove(e);
                        List<Entity> entitylist = new ArrayList<>();
                        e.world.unloadEntities(entitylist);
        				e.world.removeEntityDangerously(e);
                        e.getEntityWorld().removeEntity(e);
                        e.preventEntitySpawning = true;
                        e.world.removeEntity(e);
                        e.setInvisible(true);
                        e.world.onEntityRemoved(e);
                        e.world.loadedEntityList.remove(e);
                        e.world.removeEntity(e);
                        e.updateBlocked = true;
                        e.updateBlocked = true;
                        world.weatherEffects.remove(e);
            Chunk chunk = world.getChunkFromBlockCoords(entity.getPosition());
            if (chunk != null) {
                chunk.setHasEntities(false);
                chunk.removeEntity(e);
            }
                    }
                }
            }
    }
    }
}
