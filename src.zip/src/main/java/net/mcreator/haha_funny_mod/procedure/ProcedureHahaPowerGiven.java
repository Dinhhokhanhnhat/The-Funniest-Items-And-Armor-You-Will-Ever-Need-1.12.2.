package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureHahaPowerGiven extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureHahaPowerGiven(ElementsWhatafunnymodHaha instance) {
		super(instance, 47);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HahaPowerGiven!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure HahaPowerGiven!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) entity;
			if ("DinHoKhanhNhatA".equals(player.getName())) {
				if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1))) {
					if (!world.isRemote) {
						player.sendStatusMessage(new TextComponentString(ProcedureColorful.rainbow("The Funny Power given.")), true);
					}
					ItemStack _setstack = new ItemStack(ItemHahaFunnySword.block, 1);
					_setstack.setCount(1);
					ItemHandlerHelper.giveItemToPlayer(player, _setstack);
				} else {
					if (!world.isRemote) {
						player.sendStatusMessage(new TextComponentString(ProcedureColorful.rainbow("Bruh you foolish, you cannot get another Funny Power now.")), true);
					}
				}
			} else {
				if (!world.isRemote) {
					player.sendStatusMessage(new TextComponentString(ProcedureColorful.rainbow("Sorry, only Dinh Ho Khanh Nhat can receive the Funny Power.")), true);
				}
			}
		}
	}
}
