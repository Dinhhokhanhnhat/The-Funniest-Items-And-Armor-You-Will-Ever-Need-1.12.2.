package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.util.text.TextFormatting;

public class ProcedureColorful {
	private static final TextFormatting[] rainbow = new TextFormatting[]{TextFormatting.YELLOW, TextFormatting.GREEN, TextFormatting.AQUA,
			TextFormatting.BLUE, TextFormatting.LIGHT_PURPLE, TextFormatting.RED, TextFormatting.GOLD, TextFormatting.YELLOW, TextFormatting.GREEN,
			TextFormatting.AQUA, TextFormatting.LIGHT_PURPLE, TextFormatting.RED, TextFormatting.GOLD};
	public static String formatting(String input, TextFormatting[] colours, double delay) {
		StringBuilder sb = new StringBuilder(input.length() * 3);
		if (delay <= 0.0D)
			delay = 0.001D;
		int offset = (int) Math.floor((System.currentTimeMillis() & 0x3FFFL) / delay) % colours.length;
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			int col = (i + colours.length - offset) % colours.length;
			sb.append(colours[col].toString());
			sb.append(c);
		}
		return sb.toString();
	}

	public static String rainbow(String input) {
		return formatting(input, rainbow, 50.0D);
	}
}
