package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.World;
import net.minecraft.potion.PotionEffect;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.mcreator.haha_funny_mod.potion.PotionMeSad;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.gui.GuiSad;
import net.mcreator.haha_funny_mod.WhatafunnymodHaha;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureYouMadeMeSad extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureYouMadeMeSad(ElementsWhatafunnymodHaha instance) {
		super(instance, 20);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure YouMadeMeSad!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure YouMadeMeSad!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure YouMadeMeSad!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure YouMadeMeSad!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure YouMadeMeSad!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).addPotionEffect(new PotionEffect(PotionMeSad.potion, (int) 1000000, (int) 1));
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).openGui(WhatafunnymodHaha.instance, GuiSad.GUIID, world, x, y, z);
	}
}
