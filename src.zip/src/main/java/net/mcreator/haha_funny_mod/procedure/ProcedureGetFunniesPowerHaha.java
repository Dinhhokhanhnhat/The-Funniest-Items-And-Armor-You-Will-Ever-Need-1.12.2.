package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.command.ICommandSender;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.registries.ForgeRegistry;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

import net.mcreator.haha_funny_mod.potion.PotionMeSad;
import net.mcreator.haha_funny_mod.potion.PotionFunniesPotion;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemSpecialToolKiller;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;

import java.util.List;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.ListIterator;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureGetFunniesPowerHaha extends ElementsWhatafunnymodHaha.ModElement {
    public ProcedureGetFunniesPowerHaha(ElementsWhatafunnymodHaha instance) {
        super(instance, 45);
    }

	    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
    	Minecraft mc = Minecraft.getMinecraft();
        GuiScreen guiScreenIn = event.getGui();
        GuiScreen currentScreen = mc.currentScreen;
        if (guiScreenIn != null && (guiScreenIn instanceof net.minecraft.client.gui.GuiGameOver ||
                guiScreenIn.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {  	
            mc.currentScreen = null;
            event.setCanceled(true);
        }
    }
	
    public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure GetFunniesPowerHaha!");
            return;
        }
        if (dependencies.get("x") == null) {
            System.err.println("Failed to load dependency x for procedure GetFunniesPowerHaha!");
            return;
        }
        if (dependencies.get("y") == null) {
            System.err.println("Failed to load dependency y for procedure GetFunniesPowerHaha!");
            return;
        }
        if (dependencies.get("z") == null) {
            System.err.println("Failed to load dependency z for procedure GetFunniesPowerHaha!");
            return;
        }
        if (dependencies.get("world") == null) {
            System.err.println("Failed to load dependency world for procedure GetFunniesPowerHaha!");
            return;
        }
        Entity entity = (Entity) dependencies.get("entity");
        int x = (int) dependencies.get("x");
        int y = (int) dependencies.get("y");
        int z = (int) dependencies.get("z");
        World world = (World) dependencies.get("world");
        MinecraftServer mcserv = world.getMinecraftServer();
        Minecraft mc = Minecraft.getMinecraft();
        entity.extinguish();
		if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
                	mc.currentScreen = null;
        }
        if (entity instanceof EntityPlayerMP) {
            Advancement _adv = ((MinecraftServer) ((EntityPlayerMP) entity).mcServer).getAdvancementManager()
                    .getAdvancement(new ResourceLocation("haha_funny_mod:openhahapower"));
            AdvancementProgress _ap = ((EntityPlayerMP) entity).getAdvancements().getProgress(_adv);
            if (!_ap.isDone()) {
                Iterator _iterator = _ap.getRemaningCriteria().iterator();
                while (_iterator.hasNext()) {
                    String _criterion = (String) _iterator.next();
                    ((EntityPlayerMP) entity).getAdvancements().grantCriterion(_adv, _criterion);
                }
            }
        }

        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            ((EntityPlayer) entity).capabilities.allowEdit = true;
            ((EntityPlayer) entity).sendPlayerAbilities();
            ((EntityPlayer) entity).capabilities.allowFlying = true;
            ((EntityPlayer) entity).sendPlayerAbilities();
            ((EntityPlayer) entity).capabilities.disableDamage = true;
            ((EntityPlayer) entity).sendPlayerAbilities();
            ((EntityPlayer) entity).getEntityAttribute(EntityPlayer.REACH_DISTANCE).setBaseValue(999999999.0);
        }

        entity.updateBlocked = false;
        entity.isDead = false;
        entity.updateBlocked = false;
        entity.onGround = true;
        entity.onAddedToWorld();
        entity.isAddedToWorld();
        ((EntityPlayer) entity).setHealth(20.0F);
        entity.addedToChunk = true;
        	if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
                	mc.currentScreen = null;
        }
        if (!entity.world.loadedEntityList.contains(entity))
            entity.world.loadedEntityList.add(entity);

        if (entity instanceof EntityLivingBase) {
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.SPEED, 1000000, 6));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 1000000, 6));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.INSTANT_HEALTH, 1000000, 32767));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 1000000, 32767));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 1000000, 32767));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 1000000, 255));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.SATURATION, 1000000, 255));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 1000000, 1));
            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(PotionFunniesPotion.potion, 1000000, 32767));
        }
    
        if (entity instanceof EntityPlayer) {
            ((EntityPlayer) entity).setSpawnPoint(new BlockPos(x, y, z), true);
        }

        if (((entity instanceof EntityPlayer) ? ((EntityPlayer) entity).inventory.hasItemStack(new ItemStack(ItemSpecialToolKiller.block, (int) (1))) : false)) {
            if (entity instanceof EntityPlayer) {
                ((EntityPlayer) entity).inventory.clearMatchingItems(new ItemStack(ItemSpecialToolKiller.block, (int) (1)).getItem(), -1, (int) 1, null);
            }
            if (!world.isRemote) {
                MinecraftForge.EVENT_BUS.shutdown();
            }
            if (mcserv != null) {
                mcserv.getPlayerList().sendMessage(new TextComponentString(ProcedureColorful.rainbow("Special Funny Power turned on, the old Funny Power has been turned off! The special tool has been removed. From now on, be careful!")));
            }
        }

        if ((new Object() {
            boolean check() {
                if (entity instanceof EntityLivingBase) {
                    Collection<PotionEffect> effects = ((EntityLivingBase) entity).getActivePotionEffects();
                    for (PotionEffect effect : effects) {
                        if (effect.getPotion() == PotionMeSad.potion)
                            return true;
                    }
                }
                return false;
            }
        }.check())) {
            if (!world.isRemote && world.getMinecraftServer() != null) {
                world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
                    @Override
                    public String getName() {
                        return "";
                    }

                    @Override
                    public boolean canUseCommand(int permission, String command) {
                        return true;
                    }

                    @Override
                    public World getEntityWorld() {
                        return world;
                    }

                    @Override
                    public MinecraftServer getServer() {
                        return world.getMinecraftServer();
                    }

                    @Override
                    public boolean sendCommandFeedback() {
                        return false;
                    }

                    @Override
                    public BlockPos getPosition() {
                        return new BlockPos(x, y, z);
                    }

                    @Override
                    public Vec3d getPositionVector() {
                        return new Vec3d(x, y, z);
                    }
                }, "effect @p clear");
            }
        }

        if (!world.isRemote && mcserv != null) {
            mcserv.getCommandManager().executeCommand(new ICommandSender() {
                @Override
                public String getName() {
                    return "";
                }

                @Override
                public boolean canUseCommand(int permission, String command) {
                    return true;
                }

                @Override
                public World getEntityWorld() {
                    return world;
                }

                @Override
                public MinecraftServer getServer() {
                    return world.getMinecraftServer();
                }

                @Override
                public boolean sendCommandFeedback() {
                    return false;
                }

                @Override
                public BlockPos getPosition() {
                    return new BlockPos(x, y, z);
                }

                @Override
                public Vec3d getPositionVector() {
                    return new Vec3d(x, y, z);
                }
            }, "effect @p crazymonsters:end");
        }

        if (entity instanceof EntityPlayerMP) {
            removeHarmfulEffects((EntityPlayerMP) entity);
        }
    }

    private static void removeHarmfulEffects(EntityPlayerMP player) {
        List<PotionEffect> effects = new ArrayList<>(player.getActivePotionEffects());
        for (PotionEffect effectInstance : effects) {
            if (effectInstance.getPotion().isBadEffect()) {
                player.removePotionEffect(effectInstance.getPotion());
            }
        }
    }
}

