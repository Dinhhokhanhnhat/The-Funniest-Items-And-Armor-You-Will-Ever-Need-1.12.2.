package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.haha_funny_mod.gui.GuiHandsome;
import net.mcreator.haha_funny_mod.WhatafunnymodHaha;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureViewHandsome extends ElementsWhatafunnymodHaha.ModElement {
	public ProcedureViewHandsome(ElementsWhatafunnymodHaha instance) {
		super(instance, 15);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure ViewHandsome!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure ViewHandsome!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure ViewHandsome!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure ViewHandsome!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure ViewHandsome!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).openGui(WhatafunnymodHaha.instance, GuiHandsome.GUIID, world, x, y, z);
	}
}
