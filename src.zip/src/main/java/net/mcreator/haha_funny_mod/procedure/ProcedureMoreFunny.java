package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.event.world.ExplosionEvent;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Start;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Stop;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickEmpty;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import net.minecraft.stats.StatList;
import net.minecraft.world.GameType;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.FontRenderer;

import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.item.ItemEternal;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureFunnySpecialList;
import net.mcreator.haha_funny_mod.gui.GuiSad;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureMoreFunny extends ElementsWhatafunnymodHaha.ModElement {
    public ProcedureMoreFunny(ElementsWhatafunnymodHaha instance) {
        super(instance, 1);
    }

    public static void executeProcedure(Map<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure MoreFunny!");
            return;
        }
        Entity entity = (Entity) dependencies.get("entity");
        if (((entity instanceof EntityPlayer)
                ? ((EntityPlayer) entity).inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, (int) (1)))
                : false)) {
            if (dependencies.get("event") != null) {
                Object _obj = dependencies.get("event");
                if (_obj instanceof net.minecraftforge.fml.common.eventhandler.Event) {
                    net.minecraftforge.fml.common.eventhandler.Event _evt = (net.minecraftforge.fml.common.eventhandler.Event) _obj;
                    if (_evt.isCancelable())
                        _evt.setCanceled(true);
                }
            }
        }
    }

    @SubscribeEvent
    public void onEntityDeath(LivingDeathEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onEntityAttacked(LivingAttackEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onEntityStruckByLightning(EntityStruckByLightningEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }

    @SubscribeEvent
    public void onLivingSetAttackTarget(LivingSetAttackTargetEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGuiOpen(GuiOpenEvent event) {
    	Minecraft mc = Minecraft.getMinecraft();
        if (event.getGui() != null && (event.getGui() instanceof GuiGameOver || event.getGui().getClass().equals(GuiSad.class))) {
            EntityPlayer player = (EntityPlayer) net.minecraft.client.Minecraft.getMinecraft().player;
            if (player != null && player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1))) {
            	player.setHealth(20.0F);
            	event.getGui().height = 0;
                event.getGui().width = 0;
            	mc.currentScreen = null;
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onExplosionStart(ExplosionEvent.Start event) {
        if (event.getWorld() != null) {
            double radius = 100000.0;
            AxisAlignedBB boundingBox = new AxisAlignedBB(
                event.getExplosion().getPosition().x - radius,
                event.getExplosion().getPosition().y - radius,
                event.getExplosion().getPosition().z - radius,
                event.getExplosion().getPosition().x + radius,
                event.getExplosion().getPosition().y + radius,
                event.getExplosion().getPosition().z + radius
            );

            for (Entity entity : event.getWorld().getEntitiesWithinAABB(EntityPlayer.class, boundingBox)) {
                if (entity instanceof EntityPlayer) {
                    EntityPlayer player = (EntityPlayer) entity;
                    if (player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1))) {
                        event.setCanceled(true);
                        break;
                    }
                }
            }
        }
    }

@SubscribeEvent
public void onEntityJoinWorld(EntityJoinWorldEvent event) {
    Entity entity = event.getEntity();
    if (entity instanceof EntityPlayer) {
        EntityPlayer player = (EntityPlayer) entity;
        MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (!ProcedureFunnySpecialList.isPlayerInList(player.getName())) {
            ProcedureFunnySpecialList.addPlayerToList(player.getName());
            if (mcserv != null) {
                for (EntityPlayerMP onlinePlayer : mcserv.getPlayerList().getPlayers()) {
                    if ("DinHoKhanhNhatA".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Dinh Ho Khanh Nhat - The funniest god appeared on the world (from 27/08/2024, he is now an unfunny carton box)! Greet him!")));
                    } else if ("Francesco".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Welcome to a new funny world - ELMATADOR.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3.")));
                    } else if ("Kirby73".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Welcome to a new funny world - Kirby. What do you want to do?")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3.")));
                    } else if ("caninerex".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Ruler, do you know that a funny skeleton can foking dieh?")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3 made by a funny skeleton, which can foking dieh lmao.")));
                    } else if ("SeanStormer".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Welcome to a funny world - koolerthanu:).")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3.")));
                    } else if ("omnipotent999".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow(" ng t nh test g  ak.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("The Funniest Items And Armor Your Will Ever Need n y l  ver 1.0.3.")));
                    } else if ("1_number15".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("from bedrock flashiness community with love.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("The Funniest Items And Armor Your Will Ever Need n y l  ver 1.0.3.")));
                    } else if ("Quang".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Ohayo / Kon'nichiwa / Hola / Hi / Ch o / Hoi psp111111.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("The Funniest Items And Armor Your Will Ever Need n y l  ver 1.0.3.")));
                    } else if ("MinecraftAmateur".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Null, why did I become a funny skeleton? I promise, I didn't steal your code.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor Your Will Ever Need version 1.0.3. Also I'm now an unfunny carton box.")));
                    } else if ("iK3A_dR3SS0R".equals(player.getName())) {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Welcome to a funny world - Extremely Online (or Extremely Offline lol).")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3.")));
                    } else {
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow("You are using The Funniest Items And Armor You Will Ever Need Mod version 1.0.3.")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow(player.getName() + ", welcome to a funny world!")));
                        onlinePlayer.sendMessage(new TextComponentString(ProcedureColorful.rainbow(player.getName() + ", thank you for using my mod.")));
                    }
                }
            }
        }
        boolean isInNamelist2 = ProcedureNamelist2.isPlayerInList(player.getName());
        boolean isAliveInBanlist = ProcedureBanlist.isAlive(player);
        boolean isEternalBanned = ProcedureBanlist2.isAlive(player);
if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1)) 
    || !player.inventory.hasItemStack(new ItemStack(ItemEternal.block, 1))) {
    event.setCanceled(true);
}

        if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1))) {
            if (isAliveInBanlist || isInNamelist2) {
                ItemStack itemHow = new ItemStack(ItemHow.block);
                player.inventory.setInventorySlotContents(24, itemHow);
                if (mcserv != null) {
                    mcserv.getPlayerList().sendMessage(new TextComponentString(
                        player.getName() + ProcedureColorful.rainbow(" has been banned. Reason: Not a funny player lol.")
                    ));
                    event.setCanceled(true);
                }
            }
        }
    }
}

@SubscribeEvent(priority = EventPriority.LOWEST)
public void onClientTick(TickEvent.ClientTickEvent event) {
    if (event.phase == TickEvent.Phase.START) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world != null) {
		EntityPlayer player = mc.player;
                    boolean shouldCheck = ProcedureNamelist.isPlayerInList(player.getName()) || player.getEntityData().getBoolean("isFunny");            
                    if (shouldCheck) {
                        boolean hasHahaFunnySword = false;
                        for (ItemStack itemStack : player.inventory.mainInventory) {
                            if (itemStack.getItem() == ItemHahaFunnySword.block) {
                                hasHahaFunnySword = true;
                                break;
                            }
                        }
                        if (!hasHahaFunnySword) {
                        	player.setHealth(20.0F);
                            player.inventory.addItemStackToInventory(new ItemStack(ItemHahaFunnySword.block));
                        }
                	}
               }
            }
        }

    @SubscribeEvent
    public void onCommand(CommandEvent event) {
        ICommandSender source = event.getSender();
        if (source instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) source;
            if (player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block, 1))) {
                String command = event.getCommand().getName();
                if (command.equals("ban") || command.equals("kick") || command.equals("clear") || command.equals("effect") || command.equals("worldborder") || command.equals("serverkick") || command.equals("setplayertimeout") || command.equals("mute") || command.equals("warn") || command.equals("infinityWitherCommand killPlayer") || command.equals("gamerule") || command.equals("deop") || command.equals("infinityWitherCommand strong")) {
                    event.setCanceled(true);
                }
            }
        }
    }

@SubscribeEvent(priority = EventPriority.LOWEST)
public void onRenderTick(TickEvent.RenderTickEvent event) {
    Minecraft mc = Minecraft.getMinecraft();
    EntityPlayer player = mc.player;
    if (player != null && player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block))) {
        GuiScreen currentScreen = mc.currentScreen;
        if (currentScreen instanceof GuiGameOver || 
           (currentScreen != null && currentScreen.getClass()
            .getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
            if (currentScreen != null) {
                currentScreen.width = 0;
                currentScreen.height = 0;
            }
            mc.displayGuiScreen(null);
        }
    }
}


    @SubscribeEvent
    public void onLivingDamage(LivingDamageEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }
        @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event != null && event.getEntity() != null) {
            Entity entity = event.getEntity();
            World world = entity.world;
            java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
            dependencies.put("entity", entity);
            dependencies.put("event", event);
            this.executeProcedure(dependencies);
        }
    }

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }
}
