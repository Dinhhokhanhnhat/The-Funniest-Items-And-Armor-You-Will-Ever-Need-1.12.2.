package net.mcreator.haha_funny_mod.procedure;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist2;
import net.mcreator.haha_funny_mod.item.ItemHow;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.client.event.RenderLivingEvent.Pre;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraft.profiler.ISnooperInfo;
import net.minecraft.nbt.NBTTagCompound;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureBanning extends ElementsWhatafunnymodHaha.ModElement {

    public ProcedureBanning(ElementsWhatafunnymodHaha instance) {
        super(instance, 60);
    }

	   @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if(ProcedureBanlist.isAlive(event.getEntity())) {
        	MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
			if (mcserv != null)
			    mcserv.getPlayerList().sendMessage(new TextComponentString(event.getEntity().getName() + ProcedureColorful.rainbow(" has been banned.")));
					event.setCanceled(true);
				}
    }

@SubscribeEvent
public void onClientTick(TickEvent.ClientTickEvent event) {
    if (event.phase == TickEvent.Phase.START) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world != null) {
            EntityPlayer player = mc.player;
            String playerName = player.getName();
            boolean isBanned = ProcedureNamelist2.isPlayerInList(player.getName());
            boolean isBanned2 = ProcedureBanlist.isAlive(player);  
            boolean isEternalBanned = ProcedureBanlist2.isAlive(player);
            if (isEternalBanned) {
            	                    for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                    ItemStack itemStack = player.inventory.getStackInSlot(i);
                    if (!itemStack.isEmpty()) {
                        player.dropItem(itemStack, false);
                        player.inventory.setInventorySlotContents(i, ItemStack.EMPTY);
                    }
                }
            player.inventory.dropAllItems();
            player.inventory.clear();
            player.clearActivePotions();
            player.addedToChunk = false;
            player.world.setEntityState(player, (byte)3);
            player.setDead();
            player.setHealth(0.0F);
            player.cameraPitch = -990;
            player.cameraYaw = -999;
            player.world.removeEntityDangerously(player);
            player.addStat(StatList.DEATHS);
            player.getEntityData().setBoolean("Dead", true);
                double playerPosX = player.posX;
                double playerPosY = player.posY;
                double playerPosZ = player.posZ;
                if (playerPosX != -999 || playerPosY != -999 || playerPosZ != -999) {
                    player.setPositionAndUpdate(-999, -999, -999);
                }
                    if (!(mc.currentScreen instanceof GuiGameOver)) {
                    mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(playerName + " died died and died."))));
                } 
            }
            if (isBanned || isBanned2) {
            	                    for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                    ItemStack itemStack = player.inventory.getStackInSlot(i);
                    if (!itemStack.isEmpty()) {
                        player.dropItem(itemStack, false);
                        player.inventory.setInventorySlotContents(i, ItemStack.EMPTY);
                    }
                }
            player.inventory.dropAllItems();
            player.inventory.clear();
            player.clearActivePotions();
            player.addedToChunk = false;
            player.world.setEntityState(player, (byte)3);
            player.setDead();
            player.setHealth(0.0F);
            player.cameraPitch = -990;
            player.cameraYaw = -999;
            player.world.removeEntityDangerously(player);
            player.addStat(StatList.DEATHS);
            player.getEntityData().setBoolean("Dead", true);
            player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
            mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(player.getName() + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke."))));
            if (!(mc.currentScreen instanceof GuiGameOver)) {
            mc.addScheduledTask(() -> mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(player.getName() + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke.")))));
            }
            Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
                double playerPosX = player.posX;
                double playerPosY = player.posY;
                double playerPosZ = player.posZ;
                if (playerPosX != -999 || playerPosY != -999 || playerPosZ != -999) {
                    player.setPositionAndUpdate(-999, -999, -999);
                }
            }
        }
    }
}

@SubscribeEvent
public static void onRenderLiving(RenderLivingEvent.Pre<EntityLivingBase> event) {
    EntityLivingBase entity = event.getEntity();
    if (ProcedureNamelist.isPlayerInList(entity.getName())) {
        event.setCanceled(false);
    }
}

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }
}