package net.mcreator.haha_funny_mod.procedure;

import java.util.Set;
import java.util.HashSet;

public class ProcedureNamelist2 {
	private static Set<String> playerList = new HashSet<>();
	public static void addPlayerToList(String playerName) {
		playerList.add(playerName);
	}

	public static boolean isPlayerInList(String playerName) {
		return playerList.contains(playerName);
	}
}
