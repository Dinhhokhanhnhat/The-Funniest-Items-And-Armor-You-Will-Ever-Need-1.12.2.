package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ProcedureColorful2 extends FontRenderer {
    private static ProcedureColorful2 font;

    public static ProcedureColorful2 getFont() {
        if (font == null) {
            Minecraft mc = Minecraft.getMinecraft();
            font = new ProcedureColorful2(mc.gameSettings, new ResourceLocation("textures/font/ascii.png"), mc.renderEngine, false);
            if (mc.gameSettings.language != null) {
                font.setUnicodeFlag(mc.isUnicode());
                font.setBidiFlag(mc.getLanguageManager().isCurrentLanguageBidirectional());
            }
        }
        return font;
    }

    private ProcedureColorful2(GameSettings gameSettingsIn, ResourceLocation location, TextureManager textureManagerIn, boolean unicode) {
        super(gameSettingsIn, location, textureManagerIn, unicode);
    }

    private static long milliTime() {
        return System.nanoTime() / 1000000L;
    }

    private static double rangeRemap(double value, double low1, double high1, double low2, double high2) {
        return low2 + (value - low1) * (high2 - low2) / (high1 - low1);
    }

    @Override
    public int drawStringWithShadow(String text, float x, float y, int color) {
        float hue = (float) milliTime() / 700.0F % 1.0F;
        float hueStep = (float) rangeRemap(Math.sin(milliTime() / 1200.0F) % 6.28318D, -0.9D, 2.5D, 0.025D, 0.15D);
        float posX = x;

        String drawText = text;
        for (int i = 0; i < drawText.length(); i++) {
            char ch = drawText.charAt(i);
            if (ch == '�' && i + 1 < drawText.length()) {
                i++;
                continue;
            }

            int rainbowColor = color & 0xFF000000 | MathHelper.hsvToRGB(hue, 0.7F, 0.9F);
            float yOffset = (float) (Math.sin(i + milliTime() / 300f) * 2);
            float xOffset = (float) (Math.cos(i + milliTime() / 300f) * 2);

            super.drawStringWithShadow(String.valueOf(ch), posX + xOffset, y + yOffset, rainbowColor);

            posX += getCharWidth(ch);

            hue += hueStep;
            hue %= 1.0F;
        }
        return (int) posX;
    }
}