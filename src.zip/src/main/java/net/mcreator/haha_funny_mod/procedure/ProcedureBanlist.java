package net.mcreator.haha_funny_mod.procedure;

import java.util.HashSet;
import java.util.Set;

import net.minecraft.entity.Entity;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;


@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureBanlist {
    public static Set<String> LockID = new HashSet<>();

    public static boolean isAlive(Entity entity) {
        return LockID.contains(entity.getClass().getName());
    }

    public static boolean adding(Entity entity) {
        return LockID.add(entity.getClass().getName());
    }
}
