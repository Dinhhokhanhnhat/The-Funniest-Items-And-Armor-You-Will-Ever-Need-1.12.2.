package net.mcreator.haha_funny_mod.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.util.DamageSource;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.stats.StatList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.MoverType;

import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.item.ItemEternal;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;

import java.util.List;
import java.util.ArrayList;
import javax.annotation.Nonnull;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ProcedureMyFunnyRightClick extends ElementsWhatafunnymodHaha.ModElement {
    public ProcedureMyFunnyRightClick(ElementsWhatafunnymodHaha instance) {
        super(instance, 8);
    }
    @Nonnull
	private static final ResourceLocation BlackAndWhite = new ResourceLocation("shaders/post/sobel.json");
    public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
        EntityPlayer entityPlayer = (EntityPlayer) dependencies.get("entity");
        World world = entityPlayer.world;
        Minecraft mc = Minecraft.getMinecraft();
        MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
        boolean hasEternalItem = entityPlayer.inventory.hasItemStack(new ItemStack(ItemEternal.block));
        if (hasEternalItem) {
        mc.addScheduledTask(() -> mc.entityRenderer.loadShader(BlackAndWhite));
        }
        else {
        mc.addScheduledTask(() -> mc.entityRenderer.stopUseShader());
        }
        if (mcserv != null) {
            mcserv.getPlayerList().sendMessage(new TextComponentString(ProcedureColorful.rainbow("Dinh Ho Khanh Nhat funny right-click successful.")));
            AxisAlignedBB boundingBox = entityPlayer.getEntityBoundingBox().grow(20.0D);
            List<Entity> entitiesInRange = world.getEntitiesWithinAABB(Entity.class, boundingBox);
            for (Entity targetEntity : entitiesInRange) {
                if (targetEntity instanceof EntityPlayer) {
                    handlePlayerInteraction((EntityPlayer) targetEntity);
                } else if (targetEntity instanceof EntityLivingBase) {
                    handleEntityInteraction((EntityLivingBase) targetEntity, world);
                }
            }
        }
    }

    private static void handlePlayerInteraction(EntityPlayer player) {
        String playerName = player.getName();
        boolean hasHahaFunnySword = player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block));
        if (!hasHahaFunnySword) {
                ProcedureBanlist.adding(player);
                ProcedureNamelist2.addPlayerToList(player.getName());
                player.addStat(StatList.DEATHS, 1);
                player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
            player.inventory.clear();
            player.clearActivePotions();
            player.setHealth(0.0F);
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            player.width = 0.0F;
            player.height = 0.0F;
            player.onDeath(DamageSource.OUT_OF_WORLD);
            player.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
            player.isDead = true;
            player.setInvisible(true);
            player.onKillEntity((EntityLivingBase)player);
            player.addStat(StatList.DEATHS, 1);
            player.setLastAttackedEntity((Entity)player);
            player.onRemovedFromWorld();
            player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
					Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
        }
    }

    private static void handleEntityInteraction(EntityLivingBase entity, World world) {
        if (entity.world.isBlockLoaded(entity.getPosition())) {
        	Minecraft mc = Minecraft.getMinecraft();
            			MinecraftForge.EVENT_BUS.unregister(entity);
						ProcedureBanlist.adding(entity);
						mc.renderGlobal.onEntityRemoved(entity);
						world.setRainStrength(0.0F);
						world.setThunderStrength(0.0F);
						world.getChunkFromBlockCoords(entity.getPosition()).removeEntity(entity);
						world.loadedEntityList.remove(entity);
						world.removeEntity(entity);
						world.weatherEffects.remove(entity);
						world.onEntityRemoved(entity);
						entity.onKillCommand();
                        entity.world.loadedEntityList.remove(entity);
                        entity.chunkCoordX = -114514;
                        entity.chunkCoordY = -114514;
                        entity.setPositionAndUpdate(Float.NaN, Float.NaN, Float.NaN);
                        entity.lastTickPosX = -9999L;
                        entity.lastTickPosY = -9999L;
                        entity.lastTickPosZ = -9999L;
                        entity.onRemovedFromWorld();
                        entity.world.onEntityRemoved(entity);
                        entity.world.removeEntity(entity);
                        entity.isDead = true;
                        entity.setDead();
                        GuiIngameForge.renderBossHealth = false;
                        entity.getEntityWorld().removeEntity(entity);
                        entity.preventEntitySpawning = true;
                        entity.world.removeEntity(entity);
                        entity.setInvisible(true);
                        entity.getEntityBoundingBox().setMaxY(0.0D);
                        entity.world.onEntityRemoved(entity);
                        entity.world.loadedEntityList.remove(entity);
                        entity.world.removeEntity(entity);
                        List<Entity> entitylist = new ArrayList<>();
                        entity.world.unloadEntities(entitylist);
                        entity.world.removeEntityDangerously(entity);
                        Chunk chunk = world.getChunkFromBlockCoords(entity.getPosition());
            			if (chunk != null) {
                        chunk.setHasEntities(false);
                        chunk.removeEntity(entity);
                        entity.updateBlocked = true;
            }
        }
    }
}
