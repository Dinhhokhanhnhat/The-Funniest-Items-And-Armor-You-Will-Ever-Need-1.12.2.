package net.mcreator.haha_funny_mod.entity;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EntityRainbowLightning extends EntityLightningBolt
{
    private static final DataParameter<Float> COLOR_RED = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_GREEN = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_BLUE = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_PINK = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_YELLOW = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_ORANGE = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> COLOR_PURPLE = EntityDataManager.createKey(EntityRainbowLightning.class, DataSerializers.FLOAT);

    private final float colorRed;
    private final float colorGreen;
    private final float colorBlue;
    private final float colorPink;
    private final float colorYellow;
    private final float colorOrange;
    private final float colorPurple;

    public EntityRainbowLightning(World world)
    {
        this(world, 0, 0, 0, false, 0F, 0F, 0F, 0F, 0F, 0F, 0F);
    }

    public EntityRainbowLightning(World world, double x, double y, double z, boolean effectOnlyIn, float r, float g, float b, float p, float yColor, float o, float pu)
    {
        super(world, x, y, z, effectOnlyIn);
        colorRed = r;
        colorGreen = g;
        colorBlue = b;
        colorPink = p;
        colorYellow = yColor;
        colorOrange = o;
        colorPurple = pu;
    }

    @Override
    protected void entityInit()
    {
        getDataManager().register(COLOR_RED, colorRed);
        getDataManager().register(COLOR_GREEN, colorGreen);
        getDataManager().register(COLOR_BLUE, colorBlue);
        getDataManager().register(COLOR_PINK, colorPink);
        getDataManager().register(COLOR_YELLOW, colorYellow);
        getDataManager().register(COLOR_ORANGE, colorOrange);
        getDataManager().register(COLOR_PURPLE, colorPurple);
    }

    @Override
    public void onUpdate()
    {
        // Example behavior: Play thunder sound and impact sound when updating
        if (world.isRemote)
        {
            world.setLastLightningBolt(2); // Update lightning bolt effect on the client side
        }
        else
        {
            world.playSound(null, posX, posY, posZ, SoundEvents.ENTITY_LIGHTNING_THUNDER, SoundCategory.WEATHER, 10000.0F, 0.5F + rand.nextFloat() * 0.3F);
            world.playSound(null, posX, posY, posZ, SoundEvents.ENTITY_LIGHTNING_IMPACT, SoundCategory.WEATHER, 2.0F, 0.5F + rand.nextFloat() * 0.2F);
            
            // Optional: Set fire at the current position
            BlockPos position = new BlockPos(this);
            if (world.getBlockState(position).getMaterial() == Material.AIR && Blocks.FIRE.canPlaceBlockAt(world, position))
            {
                world.setBlockState(position, Blocks.FIRE.getDefaultState());
            }

            // Remove the entity after some time
            if (this.ticksExisted > 100) // Adjust the lifetime as needed
            {
                setDead();
            }
        }
    }

    public float[] getColor()
    {
        EntityDataManager manager = getDataManager();
        return new float[] {manager.get(COLOR_RED), manager.get(COLOR_GREEN), manager.get(COLOR_BLUE), manager.get(COLOR_PINK), manager.get(COLOR_YELLOW), manager.get(COLOR_ORANGE), manager.get(COLOR_PURPLE)};
    }
}
