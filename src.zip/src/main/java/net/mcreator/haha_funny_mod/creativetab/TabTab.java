
package net.mcreator.haha_funny_mod.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.haha_funny_mod.item.ItemEternal;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class TabTab extends ElementsWhatafunnymodHaha.ModElement {
	public TabTab(ElementsWhatafunnymodHaha instance) {
		super(instance, 66);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabtab") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemEternal.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			@Override
			public String getTranslatedTabLabel() {
				return ProcedureColorful.rainbow("Secret Of The Eternity.");
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}

			@SideOnly(Side.CLIENT)
            @Override
            public String getBackgroundImageName() {
                return "universe.png";
            }
		};
	}
	public static CreativeTabs tab;
}
