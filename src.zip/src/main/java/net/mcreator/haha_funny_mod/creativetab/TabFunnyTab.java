package net.mcreator.haha_funny_mod.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.ResourceLocation;

import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

import java.util.Random;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class TabFunnyTab extends ElementsWhatafunnymodHaha.ModElement {
  
  private static final ResourceLocation[] bar = new ResourceLocation[] {
      new ResourceLocation("haha_funny_mod", "textures/tab_1.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_2.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_3.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_4.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_5.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_6.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_7.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_8.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_9.png"),
      new ResourceLocation("haha_funny_mod", "textures/tab_10.png")
  };
  
  public static CreativeTabs tab;
  
  private static long milliTime() {
    return System.nanoTime() / 1000000000L;
  }
  
  public TabFunnyTab(ElementsWhatafunnymodHaha instance) {
    super(instance, 27);
  }
  
  public void initElements() {
    tab = new CreativeTabs("tabfunnytab") {
      
      @SideOnly(Side.CLIENT)
      @Override
      public ItemStack getTabIconItem() {
        return new ItemStack(ItemHahaFunnySword.block, 1);
      }

      @SideOnly(Side.CLIENT)
      @Override
      public boolean hasSearchBar() {
        return false;
      }

      @SideOnly(Side.CLIENT)
      @Override
      public String getBackgroundImageName() {
        return "funny_haha.png";
      }

      @SideOnly(Side.CLIENT)
      @Override
      public String getTranslatedTabLabel() {
        return ProcedureColorful.rainbow("Haha! What A Funny Creative Tab!");
      }
      
        @SideOnly(Side.CLIENT)
        public ResourceLocation getBackgroundImage() {
          Random ran = new Random(TabFunnyTab.milliTime());
          int i = ran.nextInt(10);
          return TabFunnyTab.bar[i];
        }
      };
  }
}
