
package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.Entity;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.creativetab.TabTab;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

import java.util.List;
import javax.annotation.Nullable;
import java.util.ArrayList;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemIngot extends ElementsWhatafunnymodHaha.ModElement {
	@GameRegistry.ObjectHolder("haha_funny_mod:ingot")
	public static final Item block = null;
	public ItemIngot(ElementsWhatafunnymodHaha instance) {
		super(instance, 69);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:ingot", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("ingot");
			setRegistryName("ingot");
			setCreativeTab(TabTab.tab);
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

				@Override
        public String getItemStackDisplayName(ItemStack stack) {
            return ProcedureColorful.rainbow("Rainbow Infinity Ingot.");
        }

		@Override
		public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
			super.addInformation(stack, worldIn, tooltip, flagIn);
			tooltip.add(ProcedureColorful.rainbow("The material of the higest reality..."));
			tooltip.add(ProcedureColorful.rainbow("Exclusive, Mysterious, Peerless... Infused with the infinite energy of the Omniverse, its vibrant colors pulse with an otherworldly light, hinting at the boundless power it holds."));
		}
	}
}
