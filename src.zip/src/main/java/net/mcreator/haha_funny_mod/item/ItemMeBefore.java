
package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.Entity;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TextComponentString;

import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.creativetab.TabTab;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

import java.util.List;
import javax.annotation.Nullable;
import java.util.ArrayList;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemMeBefore extends ElementsWhatafunnymodHaha.ModElement {
	@GameRegistry.ObjectHolder("haha_funny_mod:me_before")
	public static final Item block = null;
	public ItemMeBefore(ElementsWhatafunnymodHaha instance) {
		super(instance, 83);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:me_before", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 1;
			setUnlocalizedName("me_before");
			setRegistryName("me_before");
			setCreativeTab(TabTab.tab);
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

		@Override
        public String getItemStackDisplayName(ItemStack stack) {
            return ProcedureColorful.rainbow("Dinh Ho Khanh Nhat Before 27/08/2024 - a funny skeleton.");
        }

		@Override
		public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
			super.addInformation(stack, worldIn, tooltip, flagIn);
			tooltip.add(ProcedureColorful.rainbow("Fact numero cingco: ") + TextFormatting.STRIKETHROUGH + "A skeleton can foking dieh.");
			tooltip.add(ProcedureColorful.rainbow("Dinh Ho Khanh Nhat used to be a funny skeleton, which can foking dieh. He became a funny skeleton on Youtube, a video made that."));
			tooltip.add(ProcedureColorful.rainbow("But after joined a Discord server, he transformed to an unfunny carton box. He joined a Discord server and became an unfunny box."));
		}
	}
}