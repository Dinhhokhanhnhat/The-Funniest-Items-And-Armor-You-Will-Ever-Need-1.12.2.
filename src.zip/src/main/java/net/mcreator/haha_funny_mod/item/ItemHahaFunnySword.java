package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.ForgeChunkManager;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.common.ForgeChunkManager;
import net.minecraftforge.common.ForgeChunkManager.Ticket;
import net.minecraftforge.event.entity.EntityEvent;

import net.minecraft.world.World;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.world.GameRules;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.ActionResult;
import net.minecraft.server.MinecraftServer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.item.EnumAction;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import net.minecraft.world.storage.WorldInfo;
import net.minecraft.world.storage.SaveHandler;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.util.ResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiCreateWorld;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.world.GameType;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;
import net.minecraft.network.play.client.CPacketClientSettings;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.potion.PotionEffect;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.world.WorldServer;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.DamageSource;
import net.minecraft.util.NonNullList;
import net.minecraft.world.gen.ChunkProviderServer;

import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureMyFunnyRightClick;
import net.mcreator.haha_funny_mod.procedure.ProcedureHahaBreaksBlocks;
import net.mcreator.haha_funny_mod.procedure.ProcedureGetFunniesPowerHaha;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful2;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureHahaFunnyArmor;
import net.mcreator.haha_funny_mod.procedure.ProcedureFunnierGame;
import net.mcreator.haha_funny_mod.procedure.ProcedureAyoWhat;
import net.mcreator.haha_funny_mod.TrulyEnd;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.item.ItemTrulyFunnyDead;
import net.mcreator.haha_funny_mod.creativetab.TabFunnyTab;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.entity.EntityRainbowLightning;
import net.mcreator.haha_funny_mod.procedure.ProcedureFunnySwing;
import net.mcreator.haha_funny_mod.item.ItemMeBefore;
import net.mcreator.haha_funny_mod.item.ItemEternal;

import javax.annotation.Nullable;
import javax.annotation.Nonnull;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

import org.apache.logging.log4j.core.appender.rolling.action.IfFileName;
import org.lwjgl.opengl.Display;
import org.lwjgl.input.Mouse;

import akka.japi.Procedure;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemHahaFunnySword extends ElementsWhatafunnymodHaha.ModElement {
	@GameRegistry.ObjectHolder("haha_funny_mod:hahafunnysword")
	public static final Item block = null;
	public static long time;
    @Nonnull
    private static final ResourceLocation BlackAndWhite = new ResourceLocation("shaders/post/sobel.json");
	public ItemHahaFunnySword(ElementsWhatafunnymodHaha instance) {
		super(instance, 33);
	}

	@Override
	public void initElements() {
		elements.items.add(
				() -> new ItemToolCustom().setUnlocalizedName("hahafunnysword").setRegistryName("hahafunnysword").setCreativeTab(TabFunnyTab.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:hahafunnysword", "inventory"));
	}
	private static class ItemToolCustom extends Item {
		public ItemToolCustom() {
			setMaxDamage(0);
			setMaxStackSize(1);
		}


		public static Chunk GetChunkByEntity(Entity entity) {
        return entity.world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
    }

		@Override
		public EnumActionResult onItemUseFirst(EntityPlayer entity, World world, BlockPos pos, EnumFacing direction, float hitX, float hitY,
				float hitZ, EnumHand hand) {
			EnumActionResult retval = super.onItemUseFirst(entity, world, pos, direction, hitX, hitY, hitZ, hand);
			ItemStack itemstack = entity.getHeldItem(hand);
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			{
				java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
				$_dependencies.put("x", x);
				$_dependencies.put("y", y);
				$_dependencies.put("z", z);
				$_dependencies.put("world", world);
				ProcedureHahaBreaksBlocks.executeProcedure($_dependencies);
			}
			return retval;
		}

		@Override
		public String getItemStackDisplayName(ItemStack stack) {
			return ProcedureColorful.rainbow("Ultimate ") + TextFormatting.OBFUSCATED + "INCOMPREHENSIBLE" + ProcedureColorful.rainbow(" ") + TextFormatting.STRIKETHROUGH + TextFormatting.OBFUSCATED + "OMNIPOTENT" + TextFormatting.GRAY + " "
					+ ProcedureColorful.rainbow(" Dinh Ho Khanh Nhat's") + ProcedureColorful.rainbow(" Weapon ") + TextFormatting.STRIKETHROUGH
					+ "God" + ProcedureColorful.rainbow(" - Fake Strength.");
		}

@Override
public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
    super.addInformation(stack, world, tooltip, flag);
    tooltip.add(ProcedureColorful.rainbow("Very thanks to: imgood, tardigradaaa, RegularFixed, mx_wj, wxxcn10 for helping me in creating this mod!"));
    tooltip.add(ProcedureColorful.rainbow("Very thanks to authors of the mods which contain the code that I used for this mod!"));
    tooltip.add(ProcedureColorful.rainbow("You are using: The Funniest Items And Armor You Will Ever Need mod version 1.0.3 - Made by Dinh Ho Khanh Nhat."));
    tooltip.add(ProcedureColorful.rainbow("Thank you for using: The Funniest Items And Armor You Will Ever Need mod."));
    tooltip.add(ProcedureColorful.rainbow("A skeleton can foking dieh."));
    tooltip.add(ProcedureColorful.rainbow("A funny skeleton also can foking dieh."));
    tooltip.add(ProcedureColorful.rainbow("And Dinh Ho Khanh Nhat is a skeleton or a funny skeleton (just before 27/08/2024)."));
    tooltip.add(ProcedureColorful.rainbow("This is a weakened version, so it will not be as strong as expected. I made it both less lag and compatible with a lot of mods so yeah..."));
    tooltip.add(ProcedureColorful.rainbow("Dinh Ho Khanh Nhat..."));
    tooltip.add(ProcedureColorful.rainbow("What else can I say as an author..."));
    tooltip.add(ProcedureColorful.rainbow("Enjoy the game play!"));
}

		public int getEntityLifespan(ItemStack itemStack, World world) {
			return Integer.MAX_VALUE;
		}

		@Override
		public boolean canHarvestBlock(IBlockState blockIn) {
			return true;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return Float.POSITIVE_INFINITY;
		}

		@Override
		public boolean onDroppedByPlayer(ItemStack item, EntityPlayer player) {
			return false;
		}

		@Override
		public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving) {
			stack.damageItem(1, entityLiving);
			return true;
		}

		@Override
		public boolean isFull3D() {
			return true;
		}

		@Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    	}

    	@Override
    public int getMaxItemUseDuration(ItemStack stack) {
        return 64;
    	}
		@Override
	public EnumAction getItemUseAction(ItemStack itemStack) {
    	return EnumAction.BOW;
		}

    	@Override
    public int getItemBurnTime(ItemStack stack) {
        return 0;
    	}

    	@Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return false;
    	}

    	@Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return false;
    	}

    	@Override
    public boolean shouldCauseBlockBreakReset(ItemStack oldStack, ItemStack newStack) {
        return false;
    	}

   public boolean shouldRender(Entity entity, ICamera camera, double camX, double camY, double camZ) {
      return true;
   		}

		public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
			if (entity != null) {
				entity.setDead();
				if (entity instanceof EntityLivingBase) {
					((EntityLivingBase) entity).setHealth(Float.NEGATIVE_INFINITY);
					entity.onRemovedFromWorld();
					entity.getEntityWorld().removeEntity(entity);
				}
			}
			return super.onLeftClickEntity(stack, player, entity);
		}

@Override
public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
    super.onUpdate(itemstack, world, entity, slot, par5);
    int x = (int) entity.posX;
    int y = (int) entity.posY;
    int z = (int) entity.posZ;
    java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
    $_dependencies.put("entity", entity);
    $_dependencies.put("x", x);
    $_dependencies.put("y", y);
    $_dependencies.put("z", z);
    $_dependencies.put("world", world);
    ProcedureGetFunniesPowerHaha.executeProcedure($_dependencies);
    ProcedureFunnierGame.executeProcedure($_dependencies);
    ProcedureHahaFunnyArmor.executeProcedure($_dependencies);
    if (entity instanceof EntityPlayer) {
        EntityPlayer player = (EntityPlayer) entity;
        String playerName = player.getName();
        ProcedureNamelist.addPlayerToList(player.getName());
        Minecraft mc = Minecraft.getMinecraft();
        WorldServer ws = DimensionManager.getWorld(player.dimension);
        double playerPosY = player.posY;
            if (player.posY < 0) {
                player.setPositionAndUpdate(player.posX, 1, player.posZ);
            }

             if (player.posY > 200) {
                player.setPositionAndUpdate(player.posX, 80, player.posZ);
            }
        if (player.inventory.hasItemStack(new ItemStack(ItemMeBefore.block))) {
            ProcedureAyoWhat.executeProcedure($_dependencies);
        }
	if (mc.currentScreen != null && 
    (mc.currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
    mc.currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))
    ) {
    				player.setHealth(20.0F);
                	mc.currentScreen = null;
        }
        
double radius = 6.0;
int numParticles = 20;
for (int i = 0; i < numParticles; i++) {
    double angle = (2 * Math.PI / numParticles) * i;
    double offsetX = radius * Math.cos(angle);
    double offsetZ = radius * Math.sin(angle);
    double offsetY = 1.0;
    double speedX = (player.world.rand.nextDouble() - 0.5) * 0.1;
    double speedY = 0.0;
    double speedZ = (player.world.rand.nextDouble() - 0.5) * 0.1;
    player.world.spawnParticle(EnumParticleTypes.ENCHANTMENT_TABLE, 
                               player.posX + offsetX, 
                               player.posY + offsetY, 
                               player.posZ + offsetZ, 
                               speedX, speedY, speedZ);
    double fireOffsetX = radius * Math.cos(angle + Math.PI / numParticles);
    double fireOffsetZ = radius * Math.sin(angle + Math.PI / numParticles);
    player.world.spawnParticle(EnumParticleTypes.FLAME, 
                               player.posX + fireOffsetX, 
                               player.posY + offsetY, 
                               player.posZ + fireOffsetZ, 
                               speedX, speedY, speedZ);
}
player.setHealth(20.0F);
player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0F);
player.isDead = false;
player.onGround = true;
player.addedToChunk = true;
player.forceSpawn = true;
player.onAddedToWorld();
player.isAddedToWorld();
player.setInvisible(false);
player.isAirBorne = true;
player.ticksExisted = 1;
player.preventEntitySpawning = false;
player.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(2024.0F);
player.deathTime = 0;
player.hurtTime = 0;
player.maxHurtTime = 0;
player.updateBlocked = false;
player.getEntityData().setFloat("health", 20.0F);
player.setEntityInvulnerable(true);
player.setAir(0);
player.forceSpawn = true;
player.isAddedToWorld();
mc.renderGlobal.onEntityAdded((Entity)player);
player.canUseCommandBlock();
player.setUniqueId(UUID.randomUUID());
 if (!player.world.loadedEntityList.contains(player)) {
      player.world.loadedEntityList.add(player);
      player.world.updateEntity(player);
      player.updateBlocked = false;
 }
player.inventory.clearMatchingItems(new ItemStack(ItemHow.block, (int) (1)).getItem(), -1, (int) 1, null);
if (((entity instanceof EntityPlayer)
? ((EntityPlayer) entity).inventory.hasItemStack(new ItemStack(ItemHow.block, (int) (1)))
: false)) {
if (entity instanceof EntityPlayer)
((EntityPlayer) entity).inventory.clearMatchingItems(new ItemStack(ItemHow.block, (int) (1)).getItem(), -1, (int) 1,
						null);
						}

				player.inventory.clearMatchingItems(new ItemStack(ItemTrulyFunnyDead.block, (int) (1)).getItem(), -1, (int) 1, null);
            	if (((entity instanceof EntityPlayer)
				? ((EntityPlayer) entity).inventory.hasItemStack(new ItemStack(ItemTrulyFunnyDead.block, (int) (1)))
				: false)) {
		if (entity instanceof EntityPlayer)
				((EntityPlayer) entity).inventory.clearMatchingItems(new ItemStack(ItemTrulyFunnyDead.block, (int) (1)).getItem(), -1, (int) 1,
						null);
				}

    }              
    		
GameRules rules = world.getGameRules();
rules.setOrCreateGameRule("keepInventory", "true");
rules.setOrCreateGameRule("showDeathMessages", "false");
rules.setOrCreateGameRule("spawnRadius", "10");
rules.setOrCreateGameRule("mobGriefing", "false");
rules.setOrCreateGameRule("doFireTick", "false");
rules.setOrCreateGameRule("fallDamage", "false");
rules.setOrCreateGameRule("fireDamage", "false");
rules.setOrCreateGameRule("drowningDamage", "false");
rules.setOrCreateGameRule("naturalRegeneration", "true");
rules.setOrCreateGameRule("doImmediateRespawn", "true");
rules.setOrCreateGameRule("doLimitedCrafting", "false");
}

private void renameWorld(World world, String newName) {
    if (world.isRemote) {
        return;
    }

    SaveHandler saveHandler = (SaveHandler) world.getSaveHandler();
    WorldInfo worldInfo = saveHandler.loadWorldInfo();
    worldInfo.setWorldName(newName);
    saveHandler.saveWorldInfo(worldInfo);
}

@Override
public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer entity, EnumHand hand) {
	Minecraft mc = Minecraft.getMinecraft();
    ActionResult<ItemStack> retval = super.onItemRightClick(world, entity, hand);
    ItemStack itemstack = retval.getResult();
    int x = (int) entity.posX;
    int y = (int) entity.posY;
    int z = (int) entity.posZ;
    java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
    $_dependencies.put("entity", entity);
    $_dependencies.put("x", x);
    $_dependencies.put("y", y);
    $_dependencies.put("z", z);
    $_dependencies.put("world", world);
        if (!world.isRemote) {
        world.playSound(
            null,
            x, y, z,
            SoundEvents.ENTITY_WITHER_HURT,
            SoundCategory.PLAYERS,
            1.0F,
            1.0F
        );
    }
    ProcedureMyFunnyRightClick.executeProcedure($_dependencies);
    renameWorld(world, "World Controlling By Dinh Ho Khanh Nhat's Funny Power.");
    List<Entity> list = new ArrayList<>(world.loadedEntityList);
    for (Entity e : list) {
        if (e != entity && e.addedToChunk) {
            boolean hasHahaFunnySword = false;
            if (e instanceof EntityLivingBase) {
                for (ItemStack itemStack : ((EntityLivingBase) e).getHeldEquipment()) {
                    if (itemStack.getItem().getRegistryName().equals(ItemHahaFunnySword.block.getRegistryName())) {
                        hasHahaFunnySword = true;
                        break;
                    }
                }
            }
                if (e instanceof EntityPlayer) {
                	if (!hasHahaFunnySword) {
                    EntityPlayer player = (EntityPlayer) e;
                    String playerName = player.getName();
                ProcedureBanlist.adding(player);
                ProcedureNamelist2.addPlayerToList(player.getName());
            player.inventory.clear();
            player.clearActivePotions();
            player.setHealth(0.0F);
            player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            player.width = 0.0F;
            player.height = 0.0F;
            player.onDeath(DamageSource.OUT_OF_WORLD);
            player.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
            player.isDead = true;
            player.setInvisible(true);
            player.onKillEntity((EntityLivingBase)player);
            player.addStat(StatList.DEATHS, 1);
            player.setLastAttackedEntity((Entity)player);
            player.onRemovedFromWorld();
			Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
			player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
                }  
                } else {
                    if (world.isBlockLoaded(e.getPosition())) {
                        world.setRainStrength(0.0F);
                        world.setThunderStrength(0.0F);
                        world.getChunkFromBlockCoords(e.getPosition()).removeEntity(e);
                        world.loadedEntityList.remove(e);
                        world.removeEntity(e);
                        ProcedureBanlist.adding(e);
                        e.getEntityBoundingBox().setMaxY(0.0D);
                        e.world.loadedEntityList.remove(e);
                        e.onKillCommand();
                        GuiIngameForge.renderBossHealth = false;
                        e.chunkCoordX = -114514;
                        e.chunkCoordY = -114514;
                        e.setPositionAndUpdate(Float.NaN, Float.NaN, Float.NaN);
                        e.lastTickPosX = -9999L;
                        e.lastTickPosY = -9999L;
                        e.lastTickPosZ = -9999L;
                        e.onRemovedFromWorld();
                        e.world.onEntityRemoved(e);
                        e.world.loadedEntityList.remove(e);
                        e.world.removeEntity(e);
                        e.isDead = true;
                        e.setDead();
                        List<Entity> entitylist = new ArrayList<>();
                        e.world.unloadEntities(entitylist);
        				e.world.removeEntityDangerously(e);
                        e.getEntityWorld().removeEntity(e);
                        e.preventEntitySpawning = true;
                        e.world.removeEntity(e);
                        e.setInvisible(true);
                        e.world.onEntityRemoved(e);
                        e.world.loadedEntityList.remove(e);
                        e.world.removeEntity(e);
                        e.updateBlocked = true;
                        world.weatherEffects.remove(e);
                        Chunk chunk = GetChunkByEntity(e);
                        chunk.removeEntity(e);
                        chunk.setHasEntities(false);
                        Minecraft.getMinecraft().player.sendMessage(new TextComponentString(ProcedureColorful.rainbow("Trying to remove: ") + e.getClass().getName()));
                    }
                }
            }
    }
    return retval;
}

@Override
public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
    java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
    $_dependencies.put("entity", entityLiving);
    $_dependencies.put("world", entityLiving.world);
    $_dependencies.put("x", (int) entityLiving.posX);
    $_dependencies.put("y", (int) entityLiving.posY);
    $_dependencies.put("z", (int) entityLiving.posZ);
    ProcedureFunnySwing.executeProcedure($_dependencies);
    World world = entityLiving.world;
    Minecraft mc = Minecraft.getMinecraft();
    renameWorld(world, "World Controlling By Dinh Ho Khanh Nhat's Funny Power.");
    SoundEvent thunderSound = SoundEvent.REGISTRY.getObject(new ResourceLocation("minecraft:item.totem.use"));
    if (thunderSound != null) {
        world.playSound(null, entityLiving.getPosition(), thunderSound, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }
    AxisAlignedBB boundingBox = entityLiving.getEntityBoundingBox().grow(20.0D);
    List<Entity> entitiesInRange = world.getEntitiesWithinAABB(Entity.class, boundingBox);
    for (Entity entity : entitiesInRange) {
    	 if (entity instanceof EntityItem) {
             entity.setDead();
                continue;
            }
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            String playerName = player.getName();
            boolean hasHahaFunnySword = player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block));
            if (!hasHahaFunnySword) {
                ProcedureBanlist.adding(player);
                ProcedureNamelist2.addPlayerToList(player.getName());
                player.addStat(StatList.DEATHS, 1);
                player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
            player.inventory.clear();
            player.clearActivePotions();
            player.setHealth(0.0F);
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            player.width = 0.0F;
            player.height = 0.0F;
            player.onDeath(DamageSource.OUT_OF_WORLD);
            player.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
            player.isDead = true;
            player.setInvisible(true);
            player.onKillEntity((EntityLivingBase)player);
            player.addStat(StatList.DEATHS, 1);
            player.setLastAttackedEntity((Entity)player);
            player.onRemovedFromWorld();
            player.inventory.addItemStackToInventory(new ItemStack(ItemHow.block));
					Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
                continue;
            }
        } else {
        if (entity instanceof EntityLivingBase) {
            if (world.isBlockLoaded(entity.getPosition())) {
            			MinecraftForge.EVENT_BUS.unregister(entity);
						ProcedureBanlist.adding(entity);
						mc.renderGlobal.onEntityRemoved(entity);
						world.setRainStrength(0.0F);
						world.setThunderStrength(0.0F);
						world.getChunkFromBlockCoords(entity.getPosition()).removeEntity(entity);
						world.loadedEntityList.remove(entity);
						world.removeEntity(entity);
						world.weatherEffects.remove(entity);
						world.onEntityRemoved(entity);
						entity.onKillCommand();
                        entity.world.loadedEntityList.remove(entity);
                        entity.chunkCoordX = -114514;
                        entity.chunkCoordY = -114514;
                        entity.setPositionAndUpdate(Float.NaN, Float.NaN, Float.NaN);
                        entity.lastTickPosX = -9999L;
                        entity.lastTickPosY = -9999L;
                        entity.lastTickPosZ = -9999L;
                        entity.onRemovedFromWorld();
                        entity.getEntityBoundingBox().setMaxY(0.0D);
                        entity.world.onEntityRemoved(entity);
                        entity.world.removeEntity(entity);
                        entity.isDead = true;
                        entity.setDead();
                        GuiIngameForge.renderBossHealth = false;
                        entity.getEntityWorld().removeEntity(entity);
                        entity.preventEntitySpawning = true;
                        entity.world.removeEntity(entity);
                        entity.setInvisible(true);
                        entity.world.onEntityRemoved(entity);
                        entity.world.loadedEntityList.remove(entity);
                        entity.world.removeEntity(entity);
                        List<Entity> entitylist = new ArrayList<>();
                        entity.world.unloadEntities(entitylist);
                        entity.world.removeEntityDangerously(entity);
                        Chunk chunk = GetChunkByEntity(entity);
                        chunk.setHasEntities(false);
                        chunk.removeEntity(entity);
                        entity.updateBlocked = true;
           }
        }
    }
    }
    return false;
}


@Override
		public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase entityLiving, int timeLeft) {
			if (!world.isRemote && entityLiving instanceof EntityPlayer) {
				EntityPlayer player = (EntityPlayer) entityLiving;
				if (ProcedureNamelist.isPlayerInList(player.getName())) {
					ItemStack newStack = new ItemStack(this);
					if (!player.inventory.hasItemStack(newStack)) {
						if (!player.addItemStackToInventory(newStack)) {
							player.dropItem(newStack, false);
						}
					}
				}
			}
			super.onPlayerStoppedUsing(stack, world, entityLiving, timeLeft);
		}
	}
}
