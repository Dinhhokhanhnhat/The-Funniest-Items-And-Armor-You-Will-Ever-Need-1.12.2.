package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.GuiIngameForge;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLiving;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraft.world.GameRules;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.NonNullList;
import net.minecraft.stats.StatList;

import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.creativetab.TabTab;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.item.ItemHow;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist2;

import java.util.List;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.ArrayList;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemEternal extends ElementsWhatafunnymodHaha.ModElement {
    @GameRegistry.ObjectHolder("haha_funny_mod:eternal")
    public static final Item block = null;

    public ItemEternal(ElementsWhatafunnymodHaha instance) {
        super(instance, 63);
    }

    @Override
    public void initElements() {
        elements.items.add(() -> new ItemCustom());
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:eternal", "inventory"));
    }

    public static class ItemCustom extends Item {
        public ItemCustom() {
            setMaxDamage(0);
            maxStackSize = 4;
            setUnlocalizedName("eternal");
            setRegistryName("eternal");
            setCreativeTab(TabTab.tab);
        }

        @Override
        public int getItemEnchantability() {
            return 128000;
        }

        @Override
        public int getMaxItemUseDuration(ItemStack itemstack) {
            return 0;
        }

        @Override
        public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
            return 128000F;
        }
        @Override
		public boolean canHarvestBlock(IBlockState blockIn) {
			return true;
		}

		@Override
		public boolean isFull3D() {
			return true;
		}

        @Override
        public String getItemStackDisplayName(ItemStack stack) {
            return ProcedureColorful.rainbow("All Eternal Singularities.");
        }

        public int getEntityLifespan(ItemStack itemStack, World world) {
			return Integer.MAX_VALUE;
		}

        @Override
        public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
            super.addInformation(stack, worldIn, tooltip, flagIn);
            tooltip.add(ProcedureColorful.rainbow("How did you get this in survival mode? You did an impressive work."));
            tooltip.add(ProcedureColorful.rainbow("The secret of the eternity of the Omniverse..."));
            tooltip.add(ProcedureColorful.rainbow("Limitless, Eternal, Incalculable... Its presence is both awe-inspiring and foreboding, marking it as an object of both reverence and caution."));
        }

        @Override
        public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
            super.onUpdate(itemstack, world, entity, slot, par5);
            int x = (int) entity.posX;
            int y = (int) entity.posY;
            int z = (int) entity.posZ;
            if (entity instanceof EntityPlayer) {
            	EntityPlayer player = (EntityPlayer) entity;
            	        if (!world.isRemote) {
            if (player.posY < 0) {
                player.setPositionAndUpdate(player.posX, 1, player.posZ);
            }

             if (player.posY > 200) {
                player.setPositionAndUpdate(player.posX, 80, player.posZ);
            }
        }
                Minecraft mc = Minecraft.getMinecraft();
                double radius = 6.0;
int numParticles = 20;
for (int i = 0; i < numParticles; i++) {
    double angle = (2 * Math.PI / numParticles) * i;
    double offsetX = radius * Math.cos(angle);
    double offsetZ = radius * Math.sin(angle);
    double offsetY = 1.0;
    double speedX = (player.world.rand.nextDouble() - 0.5) * 0.1;
    double speedY = 0.0;
    double speedZ = (player.world.rand.nextDouble() - 0.5) * 0.1;
    player.world.spawnParticle(EnumParticleTypes.ENCHANTMENT_TABLE, 
                               player.posX + offsetX, 
                               player.posY + offsetY, 
                               player.posZ + offsetZ, 
                               speedX, speedY, speedZ);
    double fireOffsetX = radius * Math.cos(angle + Math.PI / numParticles);
    double fireOffsetZ = radius * Math.sin(angle + Math.PI / numParticles);
    player.world.spawnParticle(EnumParticleTypes.FLAME, 
                               player.posX + fireOffsetX, 
                               player.posY + offsetY, 
                               player.posZ + fireOffsetZ, 
                               speedX, speedY, speedZ);
}
                player.inventory.clearMatchingItems(new ItemStack(ItemHow.block, 1).getItem(), -1, 64, null);
                player.capabilities.allowEdit = true;
                player.sendPlayerAbilities();
                player.capabilities.allowFlying = true;
                player.sendPlayerAbilities();
                player.capabilities.disableDamage = true;
                player.sendPlayerAbilities();
				player.setHealth(20.0F);
                player.addedToChunk = true;
                player.onAddedToWorld();
                player.updateBlocked = false;
                player.deathTime = -2147483648;
                player.hurtTime = -2147483648;
player.isDead = false;
player.onGround = true;
player.addedToChunk = true;
player.forceSpawn = true;
player.onAddedToWorld();
player.isAddedToWorld();
player.setInvisible(false);
player.isAirBorne = true;
player.ticksExisted = 1;
player.world.updateEntityWithOptionalForce(player, false);
player.preventEntitySpawning = false;
player.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.24F);
player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0F);
player.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(2024.0F);
player.deathTime = 0;
player.hurtTime = 0;
player.maxHurtTime = 0;
player.updateBlocked = false;
player.getEntityData().setFloat("health", 20.0F);
player.getEntityAttribute(EntityPlayer.REACH_DISTANCE).setBaseValue(100.0);
player.getEntityAttribute(EntityPlayer.SWIM_SPEED).setBaseValue(1.2F);
GuiIngameForge.renderHealth = false;
            }
        }

@Override
public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
	World world = entityLiving.world;
	    int x = (int) entityLiving.posX;
    int y = (int) entityLiving.posY;
    int z = (int) entityLiving.posZ;
	    java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
    $_dependencies.put("entity", entityLiving);
    $_dependencies.put("world", entityLiving.world);
    $_dependencies.put("x", (int) entityLiving.posX);
    $_dependencies.put("y", (int) entityLiving.posY);
    $_dependencies.put("z", (int) entityLiving.posZ);
	        if (!world.isRemote) {
        world.playSound(
            null,
            x, y, z,
            SoundEvents.ENTITY_WITHER_DEATH,
            SoundCategory.PLAYERS,
            1.0F,
            1.0F
        );
    }
    if (!entityLiving.world.isRemote) {
        AxisAlignedBB boundingBox = entityLiving.getEntityBoundingBox().grow(25.0D);
        List<Entity> entitiesInRange = entityLiving.world.getEntitiesWithinAABB(Entity.class, boundingBox);
        for (Entity entity : entitiesInRange) {
            if (entity instanceof EntityItem) {
                entity.setDead();
                continue;
            }
            GuiIngameForge.renderBossHealth = false;
            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                String playerName = player.getName();
                boolean hasItemEternal = player.inventory.hasItemStack(new ItemStack(ItemEternal.block));
                if (!hasItemEternal) {
                    player.inventory.clear();
                    for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                    ItemStack itemStack = player.inventory.getStackInSlot(i);
                    if (!itemStack.isEmpty()) {
                        player.dropItem(itemStack, false);
                        player.inventory.setInventorySlotContents(i, ItemStack.EMPTY);
                    }
                }
                    player.clearActivePotions();
                    player.addStat(StatList.DEATHS);
                    player.setPositionAndUpdate(-999, -999, -999);
                    player.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
                    player.onDeath(DamageSource.OUT_OF_WORLD);
                    player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0F);
                    player.setHealth(0.0F);
                    player.addStat(StatList.DEATHS, 1);
                    player.onRemovedFromWorld();
                    player.world.removeEntityDangerously(player);
                    player.preventEntitySpawning = true;
                    ProcedureBanlist2.adding(player);
                }
                continue;
				} 
    if (entity == entityLiving) continue;
            	entity.setInvisible(true);
                entity.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.POSITIVE_INFINITY);
                entity.setDead();
                entity.isDead = true;
                entity.updateBlocked = true;
                entity.world.onEntityRemoved(entity);
                entity.world.loadedEntityList.remove(entity);
                entity.world.removeEntity(entity);
                List<Entity> entitylist = new ArrayList<>();
                entity.world.unloadEntities(entitylist);
                entity.preventEntitySpawning = true;
                entity.world.removeEntityDangerously(entity);
                entity.setPositionAndUpdate(Float.NaN, Float.NaN, Float.NaN);
    }
    }
    return super.onEntitySwing(entityLiving, stack);
}
    }
}