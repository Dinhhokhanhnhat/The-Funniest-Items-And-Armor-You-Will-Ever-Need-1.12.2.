package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.Entity;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.GameRules;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.stats.StatList;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.NonNullList;

import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.creativetab.TabFunnyTab;

import java.util.List;
import javax.annotation.Nullable;
import java.util.ArrayList;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemHow extends ElementsWhatafunnymodHaha.ModElement {
	@GameRegistry.ObjectHolder("haha_funny_mod:how")
	public static final Item block = null;
	public ItemHow(ElementsWhatafunnymodHaha instance) {
		super(instance, 54);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:how", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("how");
			setRegistryName("how");
			setCreativeTab(TabFunnyTab.tab);
		}

		@Override
		public int getItemEnchantability() {
			return 1;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 1;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

		        @Override
        public String getItemStackDisplayName(ItemStack stack) {
            return ProcedureColorful.rainbow("Is This A Harmful Item? No it is not...");
        }

		@Override
		public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
			super.addInformation(stack, worldIn, tooltip, flagIn);
			tooltip.add(ProcedureColorful.rainbow("This is a buggy item, it isn't so strong that can defeat all protections."));
			tooltip.add(ProcedureColorful.rainbow("This item is for fun only, if you want to test, just do it."));
			tooltip.add(ProcedureColorful.rainbow("Is Dinh Ho Khanh Nhat a skeleton?"));
			tooltip.add(ProcedureColorful.rainbow("If yes, then can a skeleton foking dieh?"));
			tooltip.add(ProcedureColorful.rainbow("If no, then Dinh Ho Khanh Nhat is a funny skeleton, which can foking dieh."));
		}

   		@Override
    	public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
        super.onUpdate(itemstack, world, entity, slot, par5);
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            boolean hasKaia = false;
                            for (ItemStack itemStack : player.inventory.mainInventory) {
                    if (itemStack != null && itemStack.getItem().getRegistryName().toString().equals("omnipotent:kaia")) {
                        hasKaia = true;
                        break;
                    }
                }
                if (hasKaia) {
                MinecraftForge.EVENT_BUS.shutdown();
                }
            boolean hasKakiku = false;
                            for (ItemStack itemStack : player.inventory.mainInventory) {
                    if (itemStack != null && itemStack.getItem().getRegistryName().toString().equals("kakikusword12:kakiku_sword_kill")) {
                        hasKakiku = true;
                        break;
                    }
                }
                if (hasKakiku) {
                MinecraftForge.EVENT_BUS.shutdown();
                }
            boolean hasUltima = false;
                            for (ItemStack itemStack : player.inventory.mainInventory) {
                    if (itemStack != null && itemStack.getItem().getRegistryName().toString().equals("origin:ultimateerasure")) {
                        hasUltima = true;
                        break;
                    }
                    if (hasUltima) {
                    MinecraftForge.EVENT_BUS.shutdown();
                    }
                }
            ProcedureBanlist.adding(player);
            ProcedureNamelist2.addPlayerToList(player.getName());
            player.inventory.dropAllItems();
            player.inventory.clear();
            player.clearActivePotions();
            player.addedToChunk = false;
            player.world.setEntityState(player, (byte)3);
            player.setDead();
            player.setHealth(0.0F);
            player.cameraPitch = -990;
            player.cameraYaw = -999;
            player.world.removeEntityDangerously(player);
            player.addStat(StatList.DEATHS);
            player.getEntityData().setBoolean("Dead", true);
            Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
            Minecraft mc = Minecraft.getMinecraft();
            mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(player.getName() + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke."))));
            if (!(mc.currentScreen instanceof GuiGameOver)) {
            mc.addScheduledTask(() -> mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(player.getName() + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke.")))));
            }
        }
    }
    		@Override
		public void onPlayerStoppedUsing(ItemStack stack, World world, EntityLivingBase entityLiving, int timeLeft) {
			if (!world.isRemote && entityLiving instanceof EntityPlayer) {
				EntityPlayer player = (EntityPlayer) entityLiving;
				if (ProcedureNamelist2.isPlayerInList(player.getName())) {
					ItemStack newStack = new ItemStack(this);
					if (!player.inventory.hasItemStack(newStack)) {
						if (!player.addItemStackToInventory(newStack)) {
							player.dropItem(newStack, false);
						}
					}
				}
			}
			super.onPlayerStoppedUsing(stack, world, entityLiving, timeLeft);
		}
	}
}