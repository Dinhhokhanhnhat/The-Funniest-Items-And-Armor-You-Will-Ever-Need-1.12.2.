package net.mcreator.haha_funny_mod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.GuiIngameForge;

import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.stats.StatList;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.potion.PotionEffect;

import net.mcreator.haha_funny_mod.creativetab.TabFunnyTab;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;
import net.mcreator.haha_funny_mod.TrulyEnd;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful2;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;
import net.mcreator.haha_funny_mod.procedure.ProcedureFunnySpecialList;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.procedure.ProcedureBanlist;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist2;
import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist3;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.annotation.Nullable;
import java.util.ArrayList;
import org.apache.logging.log4j.core.appender.rolling.action.IfFileName;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ItemTrulyFunnyDead extends ElementsWhatafunnymodHaha.ModElement {
    @GameRegistry.ObjectHolder("haha_funny_mod:truly_funny_dead")
    public static final Item block = null;

    public ItemTrulyFunnyDead(ElementsWhatafunnymodHaha instance) {
        super(instance, 80);
    }

    @Override
    public void initElements() {
        elements.items.add(() -> new ItemCustom());
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("haha_funny_mod:truly_funny_dead", "inventory"));
    }

    public static class ItemCustom extends Item {
        public ItemCustom() {
            setMaxDamage(0);
            maxStackSize = 1;
            setUnlocalizedName("truly_funny_dead");
            setRegistryName("truly_funny_dead");
            setCreativeTab(TabFunnyTab.tab);
        }

        @Override
        public int getItemEnchantability() {
            return 0;
        }

        @Override
        public int getMaxItemUseDuration(ItemStack itemstack) {
            return 0;
        }
                public static Chunk GetChunkByEntity(Entity entity) {
    return entity.world.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ);
}

        @Override
        public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
            return 1F;
        }

        @Override
        public String getItemStackDisplayName(ItemStack stack) {
            return "Can you see your truly unfunny end? Stop doing this, it is unfunny.";
        }

        @Override
        public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
            super.addInformation(stack, worldIn, tooltip, flagIn);
            tooltip.add("When Dinh Ho Khanh Nhat created this item, he was not a funny skeleton anymore... He is now an unfunny carton box (I just joined a Discord server and interested by an emoji related to the carton box lmao).");
            tooltip.add("Never put this item in your inventory, it is unfunny, like its name.");
            tooltip.add(("Fact numero cingco: ") + TextFormatting.STRIKETHROUGH + "A skeleton can foking dieh.");
            tooltip.add("I know, both normal and funny skeleton can foking dieh. But now, Dinh Ho Khanh Nhat is now an unfunny carton box, not a funny skeleton anymore.");
        }

                        @SideOnly(Side.CLIENT)
		public FontRenderer getFontRenderer(ItemStack stack)
 		{
  			return ProcedureColorful2.getFont();
 		}

        @Override
        public void onUpdate(ItemStack stack, World world, Entity entity, int itemSlot, boolean isSelected) {
            super.onUpdate(stack, world, entity, itemSlot, isSelected);
            if (entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                String playerName = player.getName();
                boolean hasSuperSword = false;
                boolean isForever = false;
                for (ItemStack itemStack : player.inventory.mainInventory) {
                    if (itemStack != null && itemStack.getItem().getRegistryName().toString().equals("tutorial_mod:super_sword")) {
                        hasSuperSword = true;
                        break;
                    }
                }
                for (ItemStack itemStack : player.inventory.mainInventory) {
                    if (itemStack != null && itemStack.getItem().getRegistryName().toString().equals("forever_love_sword:forever_love_sword")) {
                        isForever = true;
                        break;
                    }
                }
                if (hasSuperSword) {
                    ProcedureBanlist.adding(player);
                    ProcedureNamelist2.addPlayerToList(playerName);
                    player.clearActivePotions();
                    player.addedToChunk = false;
                    player.world.setEntityState(player, (byte)3);
                    player.setDead();
                    player.setHealth(0.0F);
                    player.cameraPitch = -990;
                    player.cameraYaw = -999;
                    player.world.removeEntityDangerously(player);
                    player.addStat(StatList.DEATHS);
                    player.getEntityData().setBoolean("Dead", true);
                    Minecraft mc = Minecraft.getMinecraft();
                    mc.addScheduledTask(() -> mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(playerName + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke.")))));
                    mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(playerName + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke."))));
                    if (!(mc.currentScreen instanceof GuiGameOver)) {
                        mc.addScheduledTask(() -> mc.displayGuiScreen(new GuiGameOver(new TextComponentString(ProcedureColorful.rainbow(playerName + " has been killed by a funny power of Dinh Ho Khanh Nhat and also laughed to death by a funny joke.")))));
                    }
                }
                else {
						if (!isForever) {                	
                        MinecraftForge.EVENT_BUS.shutdown();
						}
						ProcedureNamelist3.addPlayerToList(playerName);
                        Minecraft.getMinecraft().displayGuiScreen(new TrulyEnd(null));
                        Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
                        if (!world.isRemote) {
                            MinecraftServer mcserv = FMLCommonHandler.instance().getMinecraftServerInstance();
                            if (mcserv != null) {
                                mcserv.getPlayerList().sendMessage(new TextComponentString(ProcedureColorful.rainbow("This is truly " + playerName + "'s unfunny end.")));
                        }
                        }
                    }
                }
            }
        }
}
