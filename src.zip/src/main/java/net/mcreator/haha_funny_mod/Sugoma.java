package net.mcreator.haha_funny_mod;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.item.ItemStack;

import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist;
import net.mcreator.haha_funny_mod.item.ItemHahaFunnySword;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class Sugoma extends ElementsWhatafunnymodHaha.ModElement {
	    public Sugoma(ElementsWhatafunnymodHaha instance) {
        super(instance, 100);
    }
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            handleProcedureAndGui((EntityPlayer) event.getEntity());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        handleProcedureAndGui(event.player);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onGuiDraw(RenderGameOverlayEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerRespawn(PlayerRespawnEvent event) {
        handleProcedureAndGui(event.player);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
        handleProcedureAndGui(event.player);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onWorldTick(TickEvent.WorldTickEvent event) {
        if (!event.world.isRemote && event.world.playerEntities != null) {
            for (EntityPlayer player : event.world.playerEntities) {
                handleProcedureAndGui(player);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onMouseInput(InputEvent.MouseInputEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderGameOverlayPre(RenderGameOverlayEvent.Pre event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderGameOverlayPost(RenderGameOverlayEvent.Post event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderWorldLast(RenderWorldLastEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderWorldLastExtra(RenderWorldLastEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            handleProcedureAndGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            handleProcedureAndGui((EntityPlayer) event.getEntity());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    @SideOnly(Side.CLIENT)
    public static void onGuiOpen(GuiOpenEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            EntityPlayer player = Minecraft.getMinecraft().player;
            GuiScreen gui = event.getGui();
            if (gui instanceof net.minecraft.client.gui.GuiGameOver) {
                player.setHealth(20.0F);
                event.setCanceled(true);
                Minecraft.getMinecraft().displayGuiScreen(null);
                return;
            }
            if (gui != null && isModdedGui(gui)) {
                gui.width = 0;
                gui.height = 0;
                Minecraft.getMinecraft().displayGuiScreen(null);
                event.setCanceled(true);
                return;
            }

            handleProcedureAndGui(player);
        }
    }

    private static void handleProcedureAndGui(EntityPlayer player) {
        GuiScreen currentScreen = Minecraft.getMinecraft().currentScreen;
        if (player != null && ProcedureNamelist.isPlayerInList(player.getName())) {
            if (currentScreen instanceof net.minecraft.client.gui.GuiGameOver || 
                (currentScreen != null && currentScreen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/"))) {
                if (currentScreen != null) {
                    currentScreen.width = 0;
                    currentScreen.height = 0;
                    Minecraft.getMinecraft().displayGuiScreen(null);
                }
                player.setHealth(20.0F);
            }
            if (!player.inventory.hasItemStack(new ItemStack(ItemHahaFunnySword.block))) {
                player.inventory.addItemStackToInventory(new ItemStack(ItemHahaFunnySword.block));
                player.setHealth(20.0F);
            }
        }
    }

    private static boolean isModdedGui(GuiScreen screen) {
        return screen.getClass().getProtectionDomain().getCodeSource().getLocation().toString().contains("/mods/");
    }

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }
}
