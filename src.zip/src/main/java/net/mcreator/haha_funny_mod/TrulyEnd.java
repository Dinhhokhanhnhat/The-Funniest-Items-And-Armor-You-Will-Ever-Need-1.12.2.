
package net.mcreator.haha_funny_mod;

import java.io.IOException;
import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mcreator.haha_funny_mod.procedure.ProcedureColorful;

@SideOnly(Side.CLIENT)
public class TrulyEnd extends GuiScreen {
    private int enableButtonsTimer;
    private final ITextComponent causeOfDeath;

    public TrulyEnd(@Nullable ITextComponent causeOfDeath) {
        this.causeOfDeath = causeOfDeath;
    }

@Override
public void initGui() {
    this.buttonList.clear();
    this.enableButtonsTimer = 0;

    String newButtonTextRespawn = ProcedureColorful.rainbow("Dinh Ho Khanh Nhat is an unfunny carton box.");
    String newButtonTextTitleScreen = ProcedureColorful.rainbow("Dinh Ho Khanh Nhat is a funny skeleton.");
    String newButtonSpectate = ProcedureColorful.rainbow("View the world as an unfunny carton box.");
    String newButtonWorld = ProcedureColorful.rainbow("Become a skeleton, which can foking dieh.");

    if (this.mc.world.getWorldInfo().isHardcoreModeEnabled()) {
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 72, I18n.format(newButtonSpectate)));
        this.buttonList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format(newButtonWorld)));
    } else {
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 72, I18n.format(newButtonTextRespawn)));
        this.buttonList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format(newButtonTextTitleScreen)));
        if (this.mc.getSession() == null) {
            this.buttonList.get(1).enabled = false;
        }
    }
    for (GuiButton button : this.buttonList) {
        button.enabled = false;
    }
}

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
    }

    @Override
    public void confirmClicked(boolean result, int id) {
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawGradientRect(0, 0, this.width, this.height, 1615855616, -1602211792);

        GlStateManager.pushMatrix();
        GlStateManager.scale(2.0F, 2.0F, 2.0F);
        this.drawCenteredString(this.fontRenderer, I18n.format(ProcedureColorful.rainbow("You have laughed to dead by Dinh Ho Khanh Nhat's funny jokes.")), this.width / 2 / 2, 30, 16777215);
        GlStateManager.popMatrix();

        if (this.causeOfDeath != null) {
            this.drawCenteredString(this.fontRenderer, this.causeOfDeath.getFormattedText(), this.width / 2, 85, 16777215);
        }

        if (this.causeOfDeath != null && mouseY > 85 && mouseY < 85 + this.fontRenderer.FONT_HEIGHT) {
            ITextComponent clickedComponent = this.getClickedComponentAt(mouseX);
            if (clickedComponent != null && clickedComponent.getStyle().getHoverEvent() != null) {
                this.handleComponentHover(clickedComponent, mouseX, mouseY);
            }
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Nullable
    public ITextComponent getClickedComponentAt(int mouseX) {
        return null;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return true;
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        this.enableButtonsTimer++;

        if (this.enableButtonsTimer == 20) {
            for (GuiButton button : this.buttonList) {
                button.enabled = true;
            }
        }
    }
}
