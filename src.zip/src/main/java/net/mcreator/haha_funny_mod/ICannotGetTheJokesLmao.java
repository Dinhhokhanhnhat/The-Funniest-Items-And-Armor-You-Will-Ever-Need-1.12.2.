package net.mcreator.haha_funny_mod;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.text.ITextComponent;

import net.mcreator.haha_funny_mod.procedure.ProcedureNamelist3;
import net.mcreator.haha_funny_mod.TrulyEnd;
import net.mcreator.haha_funny_mod.ElementsWhatafunnymodHaha;

@ElementsWhatafunnymodHaha.ModElement.Tag
public class ICannotGetTheJokesLmao extends ElementsWhatafunnymodHaha.ModElement {
    public ICannotGetTheJokesLmao(ElementsWhatafunnymodHaha instance) {
        super(instance, 101);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    @SideOnly(Side.CLIENT)
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        checkProcedureAndDisplayGui(event.player);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    @SideOnly(Side.CLIENT)
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    @SideOnly(Side.CLIENT)
    public static void onGuiDraw(RenderGameOverlayEvent event) {
        if (Minecraft.getMinecraft().player != null) {
            checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerRespawn(PlayerRespawnEvent event) {
        checkProcedureAndDisplayGui(event.player);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
        checkProcedureAndDisplayGui(event.player);
    }

@SubscribeEvent(priority = EventPriority.HIGHEST)
public static void onWorldTick(TickEvent.WorldTickEvent event) {
    if (!event.world.isRemote && event.world.playerEntities != null) {
        for (EntityPlayer player : event.world.playerEntities) {
            checkProcedureAndDisplayGui(player);
        }
    }
}

@SubscribeEvent(priority = EventPriority.HIGHEST)
@SideOnly(Side.CLIENT)
public static void onMouseInput(InputEvent.MouseInputEvent event) {
    if (Minecraft.getMinecraft().player != null) {
        checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
    }
}

@SubscribeEvent(priority = EventPriority.HIGHEST)
@SideOnly(Side.CLIENT)
public static void onKeyInput(InputEvent.KeyInputEvent event) {
    if (Minecraft.getMinecraft().player != null) {
        checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
    }
}

@SubscribeEvent(priority = EventPriority.HIGHEST)
@SideOnly(Side.CLIENT)
public static void onRenderGameOverlayPre(RenderGameOverlayEvent.Pre event) {
    if (Minecraft.getMinecraft().player != null) {
        checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
    }
}

@SubscribeEvent(priority = EventPriority.HIGHEST)
@SideOnly(Side.CLIENT)
public static void onRenderGameOverlayPost(RenderGameOverlayEvent.Post event) {
    if (Minecraft.getMinecraft().player != null) {
        checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
    }
}

@SubscribeEvent(priority = EventPriority.HIGHEST)
@SideOnly(Side.CLIENT)
public static void onRenderWorldLast(RenderWorldLastEvent event) {
    if (Minecraft.getMinecraft().player != null) {
        checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
    }
}

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            checkProcedureAndDisplayGui((EntityPlayer) event.getEntity());
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    @SideOnly(Side.CLIENT)
    public static void onGuiOpen(GuiOpenEvent event) {
        if (Minecraft.getMinecraft().player != null && !(event.getGui() instanceof TrulyEnd)) {
            checkProcedureAndDisplayGui(Minecraft.getMinecraft().player);
        }
    }

private static void checkProcedureAndDisplayGui(EntityPlayer player) {
    if (ProcedureNamelist3.isPlayerInList(player.getName())) {
        if (!(Minecraft.getMinecraft().currentScreen instanceof TrulyEnd)) {
            Minecraft.getMinecraft().displayGuiScreen(new TrulyEnd(null));
        }
    }
}

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

}
